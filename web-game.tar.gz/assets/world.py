"""Large tiled regions, landmarks, scenery collisions, and optional residents."""
from __future__ import annotations
from dataclasses import dataclass
import math
import random
import pygame as pg
from art import tile,prop,STYLES

TILE=32
MAP_SIZE=(2304,1728)
VIEW_SIZE=(480,360)
SPAWN=(1152,1440)

LAYOUTS={
    'hub': {'frin':(608,448),'ansarac':(1056,320),'mahigul':(1472,448),'musu':(1760,800),
            'desk':(1152,1088),'guide':(1152,1312),'dreambench':(1344,1312)},
    'frin': {'npc0':(608,1056),'npc1':(1728,864),'npc2':(1120,608),
             'challenge':(1152,384),'hub':(1152,1536)},
    'ansarac': {'npc0':(640,800),'npc1':(1728,1056),'npc2':(1152,1184),
                'challenge':(1152,640),'hub':(1152,1536),
                'chart':(480,512),'food':(1856,640),'wraps':(576,1248)},
    'mahigul': {'npc0':(736,1088),'npc1':(1696,992),'npc2':(1120,832),
                'challenge':(1152,1056),'hub':(1152,1536),
                'record1':(480,576),'record2':(1152,416),'record3':(1856,576)},
    'musu': {'npc0':(320,1120),'npc1':(1920,864),'npc2':(1120,608),
             'challenge':(1152,960),'hub':(1152,1536)},
}

CHAT={
 'hub':[
  ('Mika','I like to arrive early. The fountain is a much better waiting room than a row of chairs.'),
  ('A postcard seller','Four gates, four very different postcards. I leave the backs blank. Your observations go there.'),
  ('A gardener','These flowers come from seeds, not another plane. Even a terminal can be a place worth caring for.'),
  ('A returning traveler','A map is useful, but it never tells you everything. Try a conversation along the way.'),
  ('A cafe regular',"My tea has gone cold three times. I keep getting distracted by everyone's stories."),
  ('A luggage porter','You can run by holding Shift. Your suitcase seems much lighter than mine!'),
  ('A daydreamer','If I stare at the fountain long enough, I almost see stars in the water.'),
  ('A musician','I am trying to write a tune that sounds like arriving somewhere new.'),
  ('A mapmaker','Press G for your region map. Gold markers are useful places. The red dot is you.'),
  ('A student','I brought an empty notebook. It is starting to feel heavier, in a good way.'),
  ('A gate attendant','The flight board is still here: press Tab if you want to choose a destination quickly.'),
  ('A sunset watcher','No departure is ever quite the same twice. Neither is coming back.'),
 ],
 'frin':[
  ('A cloud painter','I was going to paint a cloud, but the cloud kept suggesting other colors.'),
  ('Tavi','Last night, I dreamed of this bench. This morning, someone had already sat on it.'),
  ('A lantern maker','The lanterns glow best when two people disagree about what color they are.'),
  ('A quiet dreamer','I am keeping one small part of my dream to myself. Sharing does not mean giving everything away.'),
  ('A gardener','The star flowers seem to grow toward whatever we are imagining.'),
  ('A visitor','I took the long way around the pond. It gave me time to remember a dream.'),
  ('An illustrator','A dream can change between telling it and hearing it told back.'),
  ('A tea seller','Would you like imaginary tea? It tastes different to everyone.'),
  ('A map reader','The dream loom is in the northern garden. Follow the pink path.'),
  ('A friend',"I recognized a feeling in someone else's dream. The details were completely unfamiliar."),
  ('A kite maker','I tied a ribbon to a thought. It has been flying above the roofs all afternoon.'),
  ('A cloud watcher','Sometimes the best way to understand a strange image is to ask what it means to the person who saw it.'),
 ],
 'ansarac':[
  ('A basket weaver','A good basket needs room for a little more than you expected to carry.'),
  ('A cook','The market smells different before a departure. Everyone is drying something.'),
  ('A caretaker','We prepare the things we leave behind, too. Returning takes care as well as leaving.'),
  ('A path sweeper','Keeping this road clear is my part of the preparation.'),
  ('A storyteller','Every journey seems to add another turn to the stories we tell on the way.'),
  ('A cart mender','The wheel is fixed. Now I need to remember where I put the other wheel.'),
  ('A neighbor','If you find the supplies, bring them to the migration board north of the fountain.'),
  ('A seed keeper','These seeds are small enough to carry. That does not make them unimportant.'),
  ('A grandparent','I have made this crossing many times. I still listen carefully when the route keeper speaks.'),
  ('A child','I am going to count birds along the road. I may need a very large number.'),
  ('A scarf maker','The wraps are by the western camp. Warmth is easier to share than to describe.'),
  ('A late packer','I packed the bag. Then I remembered the bag was meant to be packed inside another bag.'),
 ],
 'mahigul':[
  ('A bookbinder','A damaged spine can be repaired. Missing pages are a different problem.'),
  ('A copyist','I check names twice. A small mistake can become a very confident later account.'),
  ('A garden reader','The courtyard is quieter than the reading room when the students all turn pages at once.'),
  ('A librarian','The three records are in the western, northern, and eastern collections.'),
  ('A questioner','Who had the chance to write something down? I keep returning to that question.'),
  ('An apprentice','I put a bookmark in the place where two accounts stopped agreeing.'),
  ('A visiting scholar','A persuasive account is not automatically a complete account.'),
  ('A caretaker','I open these windows every morning. The books are very well traveled for things that stay on shelves.'),
  ('A student poet','I found a tiny flower between two serious arguments.'),
  ('A cataloger','The archive table is in the central courtyard. Please read the records before arranging them.'),
  ('A tired researcher','I came looking for one simple answer. My notes now have several better questions.'),
  ('A local reader','Remembering together can still mean remembering differently.'),
 ],
 'musu':[
  ('A fruit seller','The bright ones are ripe. The brightest one is a wooden display fruit. Please leave that one here.'),
  ('A boat painter','Salt and sun are very good at reminding me that a boat is never finished being painted.'),
  ('A market cook',"The lunch rush starts after the boats come in. My quiet afternoon is someone else's busy morning."),
  ('A child with a kite','The wind likes my kite better over here. Or maybe it likes the palm tree.'),
  ('A gardener','People photograph the flowers. I wish they would also notice when the soil needs water.'),
  ('A dock worker','That shore is beautiful, and it is also where I start work.'),
  ('A cafe owner','We can welcome visitors and still want a say in what happens here.'),
  ('A musician','This song has changed a lot since I learned it. That is part of its life.'),
  ('A beach walker','There is a breeze by the western waterfront. Take your time.'),
  ('A local artist','I painted our town with people in it. The visitor brochure cropped most of them out.'),
  ('A traveler','I am trying to ask better questions than: where is the best photo?'),
  ('A neighbor','The visitor kiosk is near the central square. Listen to the fisher, worker, and elder before you use it.'),
 ],
}


@dataclass
class Scenery:
    image: pg.Surface
    rect: pg.Rect
    depth: int
    kind: str


@dataclass
class Resident:
    key: str
    name: str
    body: str
    pos: pg.Vector2
    home: pg.Vector2
    variant: int
    direction: str='down'
    walking: bool=False
    timer: float=0.0
    goal: pg.Vector2|None=None


class Region:
    def __init__(self,scene):
        self.scene=scene
        self.size=MAP_SIZE
        self.spawn=SPAWN
        self.layout=LAYOUTS[scene]
        self.rng=random.Random('region-v2-'+scene)
        self.cols,self.rows=MAP_SIZE[0]//TILE,MAP_SIZE[1]//TILE
        self.grid=[['grass' for _ in range(self.cols)] for _ in range(self.rows)]
        self.scenery=[]
        self.solids=[]
        self.buckets={}
        self.residents=[]
        self.signs=[]
        self.landmarks=[]
        self.build_terrain()
        self.build_residents()
        self.build_scenery()
        self.background=self.paint_terrain()
        self.minimap=self.paint_minimap()

    def fill(self,r,kind):
        x,y,w,h=r
        for yy in range(max(0,y),min(self.rows,y+h)):
            for xx in range(max(0,x),min(self.cols,x+w)):
                self.grid[yy][xx]=kind

    def road(self,start,end,width=3):
        x,y=int(start[0]//TILE),int(start[1]//TILE)
        tx,ty=int(end[0]//TILE),int(end[1]//TILE)
        # Orthogonal tiled roads keep intersections and navigation readable.
        for axis in (0,1):
            while (x if axis==0 else y)!=(tx if axis==0 else ty):
                self.fill((x-width//2,y-width//2,width,width),'path')
                if axis==0:
                    x+=1 if tx>x else -1
                else:
                    y+=1 if ty>y else -1
        self.fill((tx-width//2,ty-width//2,width,width),'path')

    def build_terrain(self):
        for y in range(self.rows):
            for x in range(self.cols):
                margin=3+(2 if (x<9 or x>62) and (y<10 or y>43) else 0)
                if x<margin or x>=self.cols-margin or y<margin or y>=self.rows-margin:
                    self.grid[y][x]='water'
                elif self.scene=='musu' and (x<8 or x>63 or y>45 or y<7):
                    self.grid[y][x]='sand'
        # Small water gardens in corners, away from all mandatory encounters.
        for cx,cy,rx,ry in [(9,9,4,3),(61,43,5,3)]:
            for y in range(cy-ry,cy+ry+1):
                for x in range(cx-rx,cx+rx+1):
                    if ((x-cx)/rx)**2+((y-cy)/ry)**2<1:
                        self.grid[y][x]='water'
        center=(1152,960)
        self.fill({'hub':(31,26,11,10),'frin':(32,8,9,8),'ansarac':(31,17,11,6),
                   'mahigul':(29,27,15,8),'musu':(31,27,11,10)}[self.scene],'plaza')
        # An outer promenade and a central north/south avenue.
        ring=[(384,352),(1920,352),(1920,1376),(384,1376),(384,352)]
        for a,b in zip(ring,ring[1:]):
            self.road(a,b,2)
        self.road(SPAWN,(1152,256),3)
        for position in self.layout.values():
            self.road(position,(1152,position[1]),2)
        # Small village lanes; each optional resident gets an accessible route.
        self.ambient_points=[(384,1120),(576,1344),(832,1280),(1440,1280),
             (1888,1152),(1952,864),(1664,544),(1440,352),
             (864,448),(448,704),(864,864),(1472,896)]
        for point in self.ambient_points:
            self.road(point,(1152,point[1]),2)
        for x,y in [(768,1472),(1536,1472),(768,672)]:
            self.road((x,y),(1152,y),2)
        self.fill((33,43,7,5),'plaza')

    def build_residents(self):
        for i,((name,body),position) in enumerate(zip(CHAT[self.scene],self.ambient_points)):
            # Avoid standing on top of a main quest character.
            point=pg.Vector2(position)
            if any(point.distance_to(p)<84 for p in self.layout.values()):
                point.x+=96
            resident=Resident(f'local{i}',name,body,point.copy(),point.copy(),i+1,timer=self.rng.uniform(0,3))
            self.residents.append(resident)
        self.signs=[
            ((768,1472),'Welcome sign','Welcome! The central avenue leads north into town. Press G to read your region map; hold Shift to run.'),
            ((1536,1472),'Town notice','People with a gold marker are connected to your challenge. Other residents are here if you would like to chat. There is no need to talk to everyone.'),
            ((768,672),'Wayfinding sign',{
                'hub':'Departures: Frin northwest, Ansarac north, Mahigul northeast, Musu Sum east. Reflection desk: central plaza.',
                'frin':'The dream loom is in the northern garden. Dreamers gather around the town paths.',
                'ansarac':'Route chart: northwest. Provisions: northeast. Warm wraps: southwest. Bring supplies to the northern migration board.',
                'mahigul':'Collections: western wing, northern wing, eastern wing. Read all three records, then use the central archive table.',
                'musu':'The fisher is by the western waterfront. The hotel worker is east. The elder is north. The visitor kiosk is in the central square.',
            }[self.scene]),
        ]

    def add(self,kind,anchor,variant=0,solid=True):
        image=prop(kind,self.scene,variant)
        r=image.get_rect(midbottom=anchor)
        self.scenery.append(Scenery(image,r,r.bottom-8,kind))
        if solid:
            if kind in ('tree','palm'):
                collision=pg.Rect(r.centerx-10,r.bottom-20,20,15)
            elif kind in ('house','gate','library','cafe'):
                collision=pg.Rect(r.x+16,r.y+66,r.width-32,r.height-72)
            elif kind=='flowers':
                return
            else:
                collision=pg.Rect(r.x+6,r.bottom-min(30,r.height)+4,r.width-12,min(26,r.height-6))
            self.solids.append(collision)
            for y in range(collision.top//64,collision.bottom//64+1):
                for x in range(collision.left//64,collision.right//64+1):
                    self.buckets.setdefault((x,y),[]).append(collision)

    def build_scenery(self):
        if self.scene=='hub':
            for i,key in enumerate(('frin','ansarac','mahigul','musu')):
                x,y=self.layout[key]
                self.add('gate',(x,y-32),i)
                self.landmarks.append((key.title() if key!='musu' else 'Musu Sum',(x,y)))
            self.add('table',(1152,1056))
            self.add('bench',self.layout['dreambench'])
            self.landmarks.append(('Sita Dulip',self.layout['guide']))
            self.landmarks.append(('Dream bench',self.layout['dreambench']))
        else:
            kind={'frin':'loom','ansarac':'board','mahigul':'table','musu':'kiosk'}[self.scene]
            x,y=self.layout['challenge']
            self.add(kind,(x,y-24))
            self.landmarks.append(({'frin':'Dream loom','ansarac':'Migration board','mahigul':'Archive table','musu':'Visitor kiosk'}[self.scene],(x,y)))
            for i in range(3):
                p=self.layout[f'npc{i}']
                self.landmarks.append(({'frin':['Iri','Sena','A visitor'],'ansarac':['Route keeper','Provisioner','Young traveler'],
                     'mahigul':['Archivist','Researcher','Student'],'musu':['Fisher','Hotel worker','Elder']}[self.scene][i],p))
            self.landmarks.append(('Airport portal',self.layout['hub']))
        if self.scene=='mahigul':
            for i in range(3):
                x,y=self.layout[f'record{i+1}']
                self.add('library',(x,y-96),i)
                self.add('bookshelf',(x,y-26),i)
                self.landmarks.append((f'Record {i+1}',(x,y)))
        if self.scene=='ansarac':
            for key,label in [('chart','Chart'),('food','Provisions'),('wraps','Wraps')]:
                x,y=self.layout[key]
                self.add('house',(x,y-48))
                self.landmarks.append((label,(x,y)))
        # Houses, cafes, stalls, and public places, set back from the lanes.
        for i,(x,y) in enumerate([(512,928),(736,1216),(1504,1216),(1824,736),
                                 (1600,448),(800,352),(448,608),(1504,800)]):
            # Preserve a generous clear zone around every quest marker.
            if any(pg.Vector2(x,y).distance_to(p)<190 for p in self.layout.values()):
                continue
            self.add('cafe' if i%3==0 else 'house',(x,y-54),i)
        for i,(x,y) in enumerate([(608,1320),(1568,1360),(1888,1008),(480,800)]):
            if not any(pg.Vector2(x,y).distance_to(p)<100 for p in self.layout.values()):
                self.add('stall',(x,y-38),i)
        if self.scene=='hub':
            self.add('fountain',(1152,928))
            self.add('airplane',(1550,248),solid=False)
            self.add('airplane',(660,248),solid=False)
        elif self.scene=='frin':
            self.add('star_shrine',(1408,1056))
            self.add('banner',(1152,736),solid=False)
        elif self.scene=='ansarac':
            self.add('windmill',(1420,800))
            for point in [(816,1100),(1504,1100),(816,608),(1504,608)]:
                self.add('crops',point,solid=False)
            self.add('banner',(1152,928),solid=False)
        elif self.scene=='mahigul':
            self.add('book_statue',(1408,1120))
            self.add('bookshelf',(864,1016),2)
            self.add('bookshelf',(1472,704),1)
        else:
            self.add('fountain',(1408,1056))
            self.add('cafe',(1920,800))
            self.add('banner',(1152,1152),solid=False)
        for p in [(992,960),(1312,960),(992,1312),(1344,1312)]:
            if not any(pg.Vector2(p).distance_to(q)<130 for q in self.layout.values()):
                self.add('bench',p)
        for p in [(1000,1440),(1310,1440),(1032,736),(1304,736),(368,1000),(1936,608)]:
            if not any(pg.Vector2(p).distance_to(q)<110 for q in self.layout.values()):
                self.add('lamp',p)
        for position,_,_ in self.signs:
            x,y=position
            self.add('sign',(x,y-16))
        # A waterfront village has working boats as well as palms and markets.
        for p in [(210,400),(2080,1370),(180,1240)]:
            self.add('boat',p,solid=False)
        reserved=list(self.layout.values())+self.ambient_points+[p for p,_,_ in self.signs]+[SPAWN]
        placed=[]
        for _ in range(680):
            x=self.rng.randrange(5,self.cols-4)*TILE
            y=self.rng.randrange(6,self.rows-4)*TILE
            if self.grid[y//TILE][x//TILE] not in ('grass','sand'):
                continue
            if any(pg.Vector2(x,y).distance_to(q)<100 for q in reserved):
                continue
            crown=pg.Rect(x-36,y-96,72,96)
            if any(crown.colliderect(item.rect.inflate(28,24)) for item in self.scenery
                   if item.kind in ('house','gate','cafe','library','fountain','loom','windmill','bookshelf','book_statue','star_shrine','board','kiosk')):
                continue
            if any(abs(x-px)<55 and abs(y-py)<55 for px,py in placed):
                continue
            self.add('palm' if self.scene=='musu' and self.rng.random()<.72 else 'tree',(x,y),self.rng.randrange(4))
            placed.append((x,y))
        for _ in range(210):
            x=self.rng.randrange(5,self.cols-4)*TILE
            y=self.rng.randrange(5,self.rows-4)*TILE
            if self.grid[y//TILE][x//TILE]=='grass':
                self.add('flowers',(x,y),self.rng.randrange(4),solid=False)

    def paint_terrain(self):
        result=pg.Surface(self.size)
        for y,row in enumerate(self.grid):
            for x,kind in enumerate(row):
                edges=0
                for bit,(dx,dy) in [(1,(0,-1)),(2,(1,0)),(4,(0,1)),(8,(-1,0))]:
                    nx,ny=x+dx,y+dy
                    if 0<=nx<self.cols and 0<=ny<self.rows:
                        other=self.grid[ny][nx]
                        if (kind=='water' and other!='water') or (kind in ('path','sand') and other=='grass'):
                            edges|=bit
                result.blit(tile(self.scene,kind,(x*3+y*7)%4,edges),(x*TILE,y*TILE))
        if self.scene=='hub':
            pg.draw.rect(result,(131,162,173),(320,160,1664,96))
            pg.draw.rect(result,(223,236,219),(320,160,1664,96),4)
            for x in range(344,1970,96):
                pg.draw.rect(result,(244,244,215),(x,204,50,6))
        return result.convert()

    def paint_minimap(self):
        result=pg.Surface((self.cols*4,self.rows*4))
        st=STYLES[self.scene]
        for y,row in enumerate(self.grid):
            for x,kind in enumerate(row):
                color=st['water'] if kind=='water' else st['path'] if kind in ('path','sand','plaza') else st['grass']
                pg.draw.rect(result,color,(x*4,y*4,4,4))
        for item in self.scenery:
            if item.kind in ('house','gate','library','cafe'):
                r=item.rect
                pg.draw.rect(result,st['roof'],(r.x//8,r.y//8,max(1,r.w//8),max(1,r.h//8)))
        return result

    def can_stand(self,pos):
        r=pg.Rect(round(pos[0])-9,round(pos[1])-5,18,14)
        if r.left<96 or r.top<96 or r.right>=self.size[0]-96 or r.bottom>=self.size[1]-96:
            return False
        for ty in range(r.top//TILE,r.bottom//TILE+1):
            for tx in range(r.left//TILE,r.right//TILE+1):
                if self.grid[ty][tx]=='water':
                    return False
        for by in range(r.top//64,r.bottom//64+1):
            for bx in range(r.left//64,r.right//64+1):
                if any(r.colliderect(solid) for solid in self.buckets.get((bx,by),())):
                    return False
        return True

    def update(self,dt,player):
        for resident in self.residents:
            resident.walking=False
            if resident.pos.distance_to(player)<76:
                resident.goal=None
                resident.timer=max(resident.timer,1.2)
                dx,dy=player-resident.pos
                resident.direction=('right' if dx>0 else 'left') if abs(dx)>abs(dy) else ('down' if dy>0 else 'up')
                continue
            if resident.goal is not None:
                vector=resident.goal-resident.pos
                if vector.length()<3:
                    resident.goal=None
                    resident.timer=self.rng.uniform(1.2,4.5)
                else:
                    delta=vector.normalize()*min(vector.length(),28*dt)
                    if self.can_stand(resident.pos+delta):
                        resident.pos+=delta
                        resident.walking=True
                        resident.direction=('right' if delta.x>0 else 'left') if abs(delta.x)>abs(delta.y) else ('down' if delta.y>0 else 'up')
                    else:
                        resident.goal=None
                        resident.timer=2
            else:
                resident.timer-=dt
                if resident.timer<=0:
                    offset=pg.Vector2(self.rng.choice([-48,0,48]),self.rng.choice([-32,0,32]))
                    goal=resident.home+offset
                    if self.can_stand(goal):
                        resident.goal=goal
                    else:
                        resident.timer=2
