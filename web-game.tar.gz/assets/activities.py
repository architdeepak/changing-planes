"""Five playable activities: travel training and a distinct game per plane."""
import math
import pygame as pg
from art import rect,emblem,WHITE,GOLD,INK,PAPER
from retro import character,pixel_frame
from content import FRAGMENTS,RECORDS,ADS

MUTED=(83,106,118)
MEMORY_SEQUENCES=((0,2,1),(1,3,0,2),(2,0,3,1,2))
MAZE_BLOCKS={(1,1),(2,1),(4,1),(5,1),(1,3),(2,3),(4,3),(5,3)}
ORB_POSITIONS=((0,0),(6,0),(2,2),(0,4),(6,4),(4,2))
PACK_SHAPES=(((0,0),(0,1),(1,1)),((0,0),(1,0),(0,1),(1,1)),((0,0),(1,0),(2,0)))
PACK_COLORS=((135,178,204),(231,162,108),(168,158,204))
PACK_NAMES=('Route chart','Dried provisions','Warm wraps')


def rotate_shape(shape):
    turned=[(-y,x) for x,y in shape]
    left=min(x for x,y in turned)
    top=min(y for x,y in turned)
    return tuple(sorted((x-left,y-top) for x,y in turned))


def packed_cells(placement):
    x,y,shape=placement
    return {(x+dx,y+dy) for dx,dy in shape}


def packing_valid(placements):
    occupied={(0,3),(5,3)}
    for placement in placements.values():
        cells=packed_cells(placement)
        if any(not(0<=x<6 and 0<=y<4) for x,y in cells) or cells&occupied:
            return False
        occupied|=cells
    return True


def packing_weights(placements):
    left=right=0
    for index,placement in placements.items():
        weight=2 if index==1 else 1
        for x,y in packed_cells(placement):
            if x<3:
                left+=weight
            else:
                right+=weight
    return left,right


class DreamGame:
    def __init__(self,game):
        self.g=game
        self.phase='watch'
        self.elapsed=0.0
        self.entered=0
        self.feedback='Watch the order. The buttons will light up one at a time.'
        self.last=-1
        self.flash=0.0
        self.done=False

    @property
    def sequence(self):
        return MEMORY_SEQUENCES[min(2,self.g.progress.dream_round)]

    def replay(self):
        if self.g.progress.portals_unlocked:
            self.done=True
            self.g.unlock_portals()
            return
        self.phase='watch'
        self.elapsed=0
        self.entered=0
        self.feedback='Watch the order, then repeat it.'

    def choose(self,index):
        if self.phase!='input':
            return
        self.last=index
        self.flash=.25
        if index!=self.sequence[self.entered]:
            self.phase='retry'
            self.elapsed=0
            self.feedback='The dream drifted. Watch the same pattern again; you keep completed rounds.'
            return
        self.entered+=1
        self.g.chime()
        if self.entered==len(self.sequence):
            self.g.progress.dream_round+=1
            self.g.save()
            self.phase='success'
            self.elapsed=0
            self.feedback='The images hold together.'

    def update(self,dt):
        self.elapsed+=dt
        self.flash=max(0,self.flash-dt)
        if self.phase=='watch' and self.elapsed>=len(self.sequence)*.85+.45:
            self.phase='input'
            self.entered=0
            self.feedback='Your turn! Repeat the images in the order you saw them.'
        elif self.phase=='retry' and self.elapsed>1.2:
            self.replay()
        elif self.phase=='success' and self.elapsed>1:
            if self.g.progress.portals_unlocked and not self.done:
                self.done=True
                self.g.unlock_portals()
            elif not self.g.progress.portals_unlocked:
                self.replay()

    def handle_key(self,key):
        if pg.K_1<=key<=pg.K_4:
            self.choose(key-pg.K_1)
        elif key==pg.K_r:
            self.replay()

    def draw(self):
        g=self.g
        g.shell('Learn to change planes',"SITA DULIP'S METHOD",(110,70,1060,670))
        g.text(f'ROUND {min(3,g.progress.dream_round+1)} / 3',160,208,25,GOLD)
        g.wrap(self.feedback,160,252,950,24,WHITE)
        active=-1
        if self.phase=='watch':
            step=int(self.elapsed/.85)
            if step<len(self.sequence) and self.elapsed%.85<.62:
                active=self.sequence[step]
        elif self.flash:
            active=self.last
        names=['Moon','Wave','Feather','Star']
        colors=[(161,154,213),(107,185,209),(142,201,167),(238,196,113)]
        for i,name in enumerate(names):
            x=160+i*245
            box=(x,340,230,190)
            g.button(name,box,lambda n=i:self.choose(n),str(i+1),selected=active==i,enabled=self.phase=='input')
            cx,cy=x+115,443
            pg.draw.circle(g.canvas,colors[i],(cx,cy),45)
            if active==i:
                pg.draw.circle(g.canvas,(250,222,133),(cx,cy),54,4)
            if i==0:
                pg.draw.circle(g.canvas,(255,244,202),(cx,cy),28)
                pg.draw.circle(g.canvas,colors[i],(cx+14,cy-9),26)
            elif i==1:
                emblem(g.canvas,(cx,cy),'frin',(255,251,221),32)
            elif i==2:
                pg.draw.line(g.canvas,(255,251,221),(cx-17,cy+23),(cx+18,cy-23),5)
                for offset in range(-15,20,9):
                    pg.draw.line(g.canvas,(255,251,221),(cx+offset,cy-offset),(cx+offset-16,cy-offset-3),5)
            else:
                points=[]
                for a in range(10):
                    angle=-math.pi/2+a*math.pi/5
                    radius=31 if a%2==0 else 14
                    points.append((cx+math.cos(angle)*radius,cy+math.sin(angle)*radius))
                pg.draw.polygon(g.canvas,(255,251,221),points)
        g.text('WATCH...' if self.phase=='watch' else f'IMAGES REPEATED: {self.entered}/{len(self.sequence)}' if self.phase=='input' else 'THE DREAM IS SHIFTING...',160,565,24,GOLD)
        g.button('Replay pattern',(160,635,400,58),self.replay,'R')
        g.wrap('Use 1-4 or click. Finish three rounds to reveal all four portals. Esc returns to the bench.',600,631,500,21,MUTED)


class PlaneGame:
    def __init__(self,game,plane):
        self.g=game
        self.plane=plane
        self.feedback=''
        self.good=False
        self.cursor=[3,4]
        self.held=None
        self.placements={}
        self.shapes=[tuple(shape) for shape in PACK_SHAPES]
        self.selected=0
        self.ghost=[0,0]
        self.order=[2,0,1]
        self.links={}

    def message(self,text,good=False):
        self.feedback=text
        self.good=good

    def move(self,dx,dy):
        if self.plane=='frin':
            p=(self.cursor[0]+dx,self.cursor[1]+dy)
            if 0<=p[0]<7 and 0<=p[1]<5 and p not in MAZE_BLOCKS:
                self.cursor=list(p)
        elif self.plane=='ansarac' and self.selected is not None:
            self.ghost[0]=max(0,min(5,self.ghost[0]+dx))
            self.ghost[1]=max(0,min(3,self.ghost[1]+dy))
        elif self.plane=='mahigul' and dx and not self.g.progress.ordered:
            other=self.selected+dx
            if 0<=other<3:
                self.order[self.selected],self.order[other]=self.order[other],self.order[self.selected]
                self.selected=other

    def maze_use(self):
        try:
            index=ORB_POSITIONS.index(tuple(self.cursor))
        except ValueError:
            self.message('Walk onto a dream image and press E to pick it up.')
            return
        if FRAGMENTS[index][2] in self.g.progress.pairs:
            return
        if self.held is None:
            self.held=index
            self.message('Carrying: '+FRAGMENTS[index][0]+'. Find its matching image.')
        elif self.held==index:
            self.held=None
            self.message('You set the image down.')
        elif self.g.progress.pair(self.held,index):
            self.held=None
            self.g.chime()
            self.g.save()
            self.message('A dream is connected!',True)
            if 'frin' in self.g.progress.completed:
                self.g.complete()
        else:
            self.message('These images tell different dreams. Keep searching for the shared motif.')

    def select_piece(self,index):
        self.selected=index
        if index in self.placements:
            x,y,shape=self.placements.pop(index)
            self.ghost=[x,y]
            self.shapes[index]=shape
        else:
            self.ghost=[0,0]

    def rotate_piece(self):
        if self.selected is not None:
            self.shapes[self.selected]=rotate_shape(self.shapes[self.selected])

    def place_piece(self):
        if self.selected is None:
            self.message('All supplies are placed. Press Enter to check the load.')
            return
        proposed=dict(self.placements)
        proposed[self.selected]=(*self.ghost,self.shapes[self.selected])
        if not packing_valid(proposed):
            self.message('Keep every square inside the cart. Avoid other supplies and the two wheel blocks.')
            return
        self.placements=proposed
        remaining=[i for i in range(3) if i not in self.placements]
        self.selected=remaining[0] if remaining else None
        self.ghost=[0,0]
        self.message('Packed. Keep the left and right weights close.',True)

    def check_pack(self):
        if len(self.placements)!=3 or not packing_valid(self.placements):
            self.message('Fit all three supplies into the cart first.')
            return
        left,right=packing_weights(self.placements)
        if abs(left-right)>2:
            self.message('The cart leans! Move a supply so the side weights differ by no more than 2.')
            return
        keys=['chart','food','wraps']
        while self.g.progress.deliveries<3:
            if not self.g.progress.deliver(keys[self.g.progress.deliveries]):
                self.message('Gather every supply before packing the cart.')
                return
        self.g.complete()

    def connect(self,evidence):
        self.links[self.selected]=evidence
        self.message('Evidence connected. Check all three links when you are ready.',True)
        self.selected=(self.selected+1)%3

    def check_evidence(self):
        expected={0:1,1:2,2:0}
        if self.links!=expected:
            self.message('Some links do not address the promise. Compare coast / labor / change, then reconnect.')
            return
        while self.g.progress.comparisons<3:
            self.g.progress.compare(self.g.progress.comparisons)
        self.g.complete()

    def check_timeline(self):
        if self.g.progress.order_records(self.order):
            self.g.save()
            self.message('The sequence is restored. What does the evidence support?',True)
        else:
            self.message('Look at the dates. The shared agreement comes before the closure and retaliation.')

    def handle_key(self,key):
        moves={pg.K_LEFT:(-1,0),pg.K_a:(-1,0),pg.K_RIGHT:(1,0),pg.K_d:(1,0),
               pg.K_UP:(0,-1),pg.K_w:(0,-1),pg.K_DOWN:(0,1),pg.K_s:(0,1)}
        if key in moves and self.plane in ('frin','ansarac','mahigul'):
            self.move(*moves[key])
            return
        if self.plane=='frin':
            if key in (pg.K_e,pg.K_RETURN,pg.K_SPACE):
                self.maze_use()
        elif self.plane=='ansarac':
            if pg.K_1<=key<=pg.K_3:
                self.select_piece(key-pg.K_1)
            elif key==pg.K_r:
                self.rotate_piece()
            elif key in (pg.K_e,pg.K_SPACE):
                self.place_piece()
            elif key==pg.K_RETURN:
                self.check_pack()
        elif self.plane=='mahigul':
            if pg.K_1<=key<=pg.K_3:
                if self.g.progress.ordered:
                    self.g.interpret(key-pg.K_1)
                else:
                    self.selected=key-pg.K_1
            elif key==pg.K_RETURN and not self.g.progress.ordered:
                self.check_timeline()
        elif self.plane=='musu':
            if pg.K_1<=key<=pg.K_3:
                self.selected=key-pg.K_1
            elif pg.K_4<=key<=pg.K_6:
                self.connect(key-pg.K_4)
            elif key==pg.K_RETURN:
                self.check_evidence()
            elif key==pg.K_r:
                self.links.clear()

    def grid_click(self,point):
        if self.plane=='frin':
            x,y=(int(point[0])-160)//64,(int(point[1])-275)//64
            if abs(x-self.cursor[0])+abs(y-self.cursor[1])==1:
                self.move(x-self.cursor[0],y-self.cursor[1])
            elif (x,y)==tuple(self.cursor):
                self.maze_use()
        elif self.plane=='ansarac':
            self.ghost=[(int(point[0])-190)//60,(int(point[1])-300)//60]
            self.place_piece()

    def draw(self):
        g=self.g
        names={'frin':'Navigate the shared dream','ansarac':'Pack for the crossing',
               'mahigul':'Reconstruct the beginning','musu':'Build the evidence board'}
        g.shell(names[self.plane],self.plane.upper()+' / PLAYABLE CHALLENGE',(110,50,1060,710))
        getattr(self,'draw_'+self.plane)()
        if self.feedback:
            g.wrap(self.feedback,160,704 if self.plane=='musu' else 685,960,21,(43,122,104) if self.good else (163,91,58),3)

    def draw_frin(self):
        g=self.g
        g.wrap('Move through the mist. Carry one image to its matching dream.',160,208,970,24,MUTED)
        colors={'sea':(106,176,211),'tree':(164,146,205),'bird':(231,183,113)}
        for y in range(5):
            for x in range(7):
                box=pg.Rect(160+x*64,275+y*64,62,62)
                rect(g.canvas,(92,107,147) if (x,y) in MAZE_BLOCKS else (219,231,224),box)
                rect(g.canvas,(156,182,192),box,0,2)
                if (x,y) in MAZE_BLOCKS:
                    pg.draw.circle(g.canvas,(131,141,177),box.center,19)
        for index,pos in enumerate(ORB_POSITIONS):
            motif=FRAGMENTS[index][2]
            if motif in g.progress.pairs or self.held==index:
                continue
            center=(192+pos[0]*64,307+pos[1]*64)
            emblem(g.canvas,center,motif,colors[motif],22)
        x,y=self.cursor
        g.canvas.blit(character(0,'down',0,True),(172+x*64,279+y*64))
        g.buttons.append((pg.Rect(160,275,448,320),lambda:self.grid_click(g.mouse),None))
        g.text(f'DREAMS: {len(g.progress.pairs)} / 3',674,280,25,GOLD)
        g.wrap('ARROWS / WASD: move\nE: pick up or connect\nClick a neighboring tile to move.',674,325,420,22,MUTED)
        under=next((i for i,pos in enumerate(ORB_POSITIONS) if pos==tuple(self.cursor)),None)
        index=self.held if self.held is not None else under
        if index is not None:
            g.text('CARRYING' if self.held is not None else 'DREAM IMAGE',674,442,18,GOLD)
            g.wrap(FRAGMENTS[index][0]+': '+FRAGMENTS[index][1],674,475,420,24,WHITE)
        g.button('Use dream image',(674,585,420,60),self.maze_use,'E')

    def draw_ansarac(self):
        g=self.g
        g.wrap('Fit all supplies into the cart. Balance its left and right sides.',160,208,970,24,MUTED)
        for y in range(4):
            for x in range(6):
                box=(190+x*60,300+y*60,58,58)
                rect(g.canvas,(225,205,161) if (x,y) not in ((0,3),(5,3)) else (88,108,115),box)
                rect(g.canvas,(148,143,117),box,0,2)
        for index,placement in self.placements.items():
            for x,y in packed_cells(placement):
                rect(g.canvas,PACK_COLORS[index],(193+x*60,303+y*60,52,52))
                g.text(str(index+1),219+x*60,320+y*60,22,WHITE,center=True)
        if self.selected is not None:
            candidate=(*self.ghost,self.shapes[self.selected])
            proposed={**self.placements,self.selected:candidate}
            color=(51,141,113) if packing_valid(proposed) else (196,101,90)
            for x,y in packed_cells(candidate):
                if 0<=x<6 and 0<=y<4:
                    rect(g.canvas,color,(194+x*60,304+y*60,50,50),0,4)
        g.buttons.append((pg.Rect(190,300,360,240),lambda:self.grid_click(g.mouse),None))
        for i,name in enumerate(PACK_NAMES):
            g.button(name+(' / packed' if i in self.placements else ''),(680,280+i*95,420,80),lambda n=i:self.select_piece(n),str(i+1),self.selected==i,detail='Heavy: 2 per square' if i==1 else 'Light: 1 per square')
        left,right=packing_weights(self.placements)
        g.text(f'LEFT {left}   /   RIGHT {right}',190,560,24,GOLD)
        g.text('DIFFERENCE MUST BE 2 OR LESS',190,586,16,MUTED)
        g.button('Rotate piece',(160,605,420,58),self.rotate_piece,'R')
        g.button('Check load',(680,605,420,58),self.check_pack,'ENTER')
        g.wrap('Arrows move / E places / R rotates / 1-3 selects. Or click a cart square.',160,249,970,20,MUTED)

    def draw_mahigul(self):
        g=self.g
        if g.progress.ordered:
            g.wrap('The timeline is restored. What does the evidence support?',160,215,970,24,GOLD)
            choices=['The communities were always enemies.','Fear, a closure, and retaliation damaged a shared agreement.','Only one account is needed to understand the conflict.']
            for i,text in enumerate(choices):
                g.button(text,(160,320+i*95,940,78),lambda n=i:g.interpret(n),str(i+1))
            return
        g.wrap('Select a record, then move it left or right to rebuild the timeline.',160,208,970,24,MUTED)
        summaries=['YEAR 1\nA crossing is shared. A difficult season strains the agreement.',
                   'YEAR 2\nA crossing closes after an unconfirmed rumor. Supplies are cut off.',
                   'YEAR 3\nRetaliation follows. Later speeches omit the old agreement.']
        for slot,index in enumerate(self.order):
            x=160+slot*320
            g.button(RECORDS[index][1].split(' / ')[1],(x,290,300,275),lambda n=slot:setattr(self,'selected',n),str(slot+1),self.selected==slot)
            g.wrap(summaries[index],x+22,389,253,23,WHITE)
            emblem(g.canvas,(x+150,352),'mahigul',(95,157,154),23)
        g.button('Move left',(160,600,290,60),lambda:self.move(-1,0),'LEFT')
        g.button('Move right',(470,600,290,60),lambda:self.move(1,0),'RIGHT')
        g.button('Test timeline',(780,600,320,60),self.check_timeline,'ENTER')

    def draw_musu(self):
        g=self.g
        g.wrap('Select a brochure claim, then connect the islander whose account challenges it.',160,208,970,24,MUTED)
        witness=[('The elder','People change and decide how they are described.'),
                 ('The fisher','A working shore, not an empty beach.'),
                 ('The hotel worker',"Rest depends on other people's work.")]
        for ad,evidence in self.links.items():
            color=[(81,148,172),(176,139,81),(145,124,176)][ad]
            pg.draw.lines(g.canvas,color,False,[(575,334+ad*111),(650,334+ad*111),(650,334+evidence*111),(725,334+evidence*111)],5)
        for i in range(3):
            g.button(ADS[i][0],(160,280+i*111,415,96),lambda n=i:setattr(self,'selected',n),str(i+1),self.selected==i)
            name,body=witness[i]
            g.button(name,(725,280+i*111,390,96),lambda n=i:self.connect(n),str(i+4),detail=body)
        g.button('Clear links',(160,635,415,58),self.links.clear,'R')
        g.button('Check evidence',(725,635,390,58),self.check_evidence,'ENTER')
