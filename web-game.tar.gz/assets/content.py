"""Original game writing inspired by Changing Planes.

The invented characters, tasks, records, and dialogue are interpretations, not
quotations or factual summaries of Le Guin's chapters. Keep that distinction
when adapting the project for class.
"""

PLANES = {
    "frin": {
        "name": "Frin", "subtitle": "THE SHARED DREAM", "color": (170, 152, 226),
        "theme": "Belonging & shared imagination",
        "intro": "Here, dreams meet. Listen to the dreamers, then find the fragments that belong to the same story.",
        "objective": "Visit the dream loom. Pair six fragments into three connected dreams.",
        "reflection": "A story may belong to more than one person. Listening helps us find connections without assuming every experience is our own.",
        "npcs": [
            ("Iri", (240, 350), "I remember a door under the sea. Someone else remembers a key made of coral. Our images are different, but they may open the same story."),
            ("Sena", (730, 375), "My dream held a tree full of stars. A visitor saw roots reaching into the night. Look for a shared image, not identical words."),
            ("A visitor", (465, 490), "A silver bird flew out of my window. Across the dream, someone heard its song. Sharing a dream means making room for another voice."),
        ],
    },
    "ansarac": {
        "name": "Ansarac", "subtitle": "BEFORE THE DEPARTURE", "color": (231, 187, 111),
        "theme": "Seasonal movement & community",
        "intro": "The season is changing. Gather what the travelers need, listen to their plans, and help prepare for the journey.",
        "objective": "Find three supplies, then bring them to the migration board.",
        "reflection": "Movement can be a shared way of living. Helping begins by asking what a community needs, rather than deciding for it.",
        "npcs": [
            ("The route keeper", (250, 335), "We need a route chart to guide our group. The chart is near the western shelter. Our journey follows the season; it is not a holiday."),
            ("The provisioner", (700, 350), "Travelers need dried provisions. Look near the eastern storehouse. Everyone contributes; no single traveler carries the whole community."),
            ("A young traveler", (475, 490), "We need warm wraps for the cold crossing. They are beside the southern camp. Leaving and returning are both parts of home."),
        ],
    },
    "mahigul": {
        "name": "Mahigul", "subtitle": "THE UNFINISHED ARCHIVE", "color": (121, 188, 189),
        "theme": "Memory, evidence & conflict",
        "intro": "The archive holds competing accounts. Read three fictional records, reconstruct their sequence, and decide what the evidence supports.",
        "objective": "Read all three records. Use the archive table to reconstruct the conflict.",
        "reflection": "An archive is not a single voice. Comparing accounts reveals how fear and selective memory can turn a dispute into a lasting conflict.",
        "npcs": [
            ("The archivist", (240, 365), "Read every record before deciding. Dates can help with sequence, but a date alone cannot tell you whose voice is missing."),
            ("A researcher", (735, 360), "A later retelling can make a complicated beginning sound inevitable. Compare the early record with what people claimed afterward."),
            ("A student", (490, 490), "I thought the later speeches told the whole story. Then I read the first agreement. It changes the questions I want to ask."),
        ],
    },
    "musu": {
        "name": "Musu Sum", "subtitle": "BEYOND THE BROCHURE", "color": (113, 199, 172),
        "theme": "Tourism, power & perspective",
        "intro": "The advertisements promise a perfect escape. Speak with islanders, then compare the promises with the experiences they describe.",
        "objective": "Listen to three islanders, then examine the visitor kiosk.",
        "reflection": "A place is someone's home before it is a visitor's destination. Advertising can hide the labor, limits, and choices behind an experience.",
        "npcs": [
            ("The fisher", (235, 360), "The brochure promises an empty coast. Our boats use that shore every morning. A beach can look empty to visitors while still being part of someone's livelihood."),
            ("The hotel worker", (720, 360), "It says relaxation requires no effort. Guests rest because people cook, wash, repair, and clean. That work is easy to leave outside the picture."),
            ("The elder", (480, 490), "The advertisement calls us timeless. We make choices and change, like anyone else. Let us decide what to share and how to describe ourselves."),
        ],
    },
}

FRAGMENTS = [
    ("A coral key", "A small key grows from a reef.", "sea"),
    ("The night roots", "Roots reach upward into constellations.", "tree"),
    ("A distant song", "A silver wing leaves a melody behind.", "bird"),
    ("The underwater door", "A locked door waits below the tide.", "sea"),
    ("The window bird", "A silver bird flies through an open window.", "bird"),
    ("The star tree", "Stars hang like fruit on dark branches.", "tree"),
]

SUPPLIES = [
    ("chart", "Route chart", (135, 260)),
    ("food", "Dried provisions", (820, 270)),
    ("wraps", "Warm wraps", (650, 510)),
]
DELIVERIES = [
    ("The route keeper", "Which supply helps the group navigate?", "chart"),
    ("The provisioner", "Which supply will feed travelers on the crossing?", "food"),
    ("The young traveler", "Which supply protects travelers from the cold?", "wraps"),
]
RECORDS = [
    ("record1", "01 / A shared crossing", (155, 250), "Year 1. Two communities agree to share a river crossing. Each promises to keep it open. A difficult season puts the agreement under strain."),
    ("record2", "02 / The closed crossing", (480, 230), "Year 2. One council closes the crossing after rumors of a raid. No raid is confirmed in this record. Families on the other bank lose access to supplies."),
    ("record3", "03 / The inherited story", (805, 250), "Year 3. Retaliation follows the closure. Later speeches describe the other community as an ancient enemy, leaving out the earlier agreement."),
]
ADS = [
    ("An untouched coast, just for you.", "Whose account complicates this promise?", 0, "The fisher describes a working shore. 'Empty' depends on whose use of the land is counted."),
    ("Relaxation without effort.", "Whose account reveals the work behind this promise?", 1, "The worker describes the labor that makes a visitor's rest possible."),
    ("A timeless people, forever unchanged.", "Whose account challenges this description?", 2, "The elder insists on people's ability to change and define their own lives."),
]

SOURCES = [
    ("Literary inspiration", "Ursula K. Le Guin, Changing Planes (2003).", "https://www.ursulakleguin.com/changing-planes"),
    ("Library reference", "Pygame documentation; implemented with pygame-ce.", "https://www.pygame.org/docs/"),
    ("Planned learning resource", "Clear Code: Creating a Zelda style game in Python.", "https://www.youtube.com/watch?v=QU1pPzEGrqw"),
]
