"""Browser entry point for the complete Changing Planes game."""
import asyncio
import sys
import pygame
from game import Game

async def main():
    game = Game()
    if sys.platform == "emscripten":
        import platform
        platform.window.window_resize()
        platform.window.canvas.focus()
    await game.run()

asyncio.run(main())
