"""Save data and puzzle rules, independent of rendering."""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from dataclasses import dataclass, field

from content import PLANES, FRAGMENTS, DELIVERIES, ADS


@dataclass
class Progress:
    visited: set[str] = field(default_factory=set)
    completed: set[str] = field(default_factory=set)
    clues: set[str] = field(default_factory=set)
    pairs: set[str] = field(default_factory=set)
    deliveries: int = 0
    comparisons: int = 0
    ordered: bool = False
    finished: bool = False
    muted: bool = False
    intro_seen: bool = False
    met_sita: bool = False
    dream_round: int = 0

    @property
    def portals_unlocked(self) -> bool:
        return self.dream_round == 3

    def collect(self, clue: str) -> bool:
        fresh = clue not in self.clues
        self.clues.add(clue)
        return fresh

    def pair(self, first: int, second: int) -> bool:
        if first == second or not (0 <= first < 6 and 0 <= second < 6):
            return False
        motif = FRAGMENTS[first][2]
        if motif == FRAGMENTS[second][2]:
            self.pairs.add(motif)
            if len(self.pairs) == 3:
                self.completed.add("frin")
            return True
        return False

    def deliver(self, item: str) -> bool:
        if self.deliveries >= 3 or item not in self.clues:
            return False
        if DELIVERIES[self.deliveries][2] != item:
            return False
        self.deliveries += 1
        if self.deliveries == 3:
            self.completed.add("ansarac")
        return True

    def order_records(self, order: list[int]) -> bool:
        if not {"record1", "record2", "record3"} <= self.clues:
            return False
        if order != [0, 1, 2]:
            return False
        self.ordered = True
        return True

    def interpret_archive(self, choice: int) -> bool:
        if self.ordered and choice == 1:
            self.completed.add("mahigul")
            return True
        return False

    def compare(self, choice: int) -> bool:
        if not {"musu_npc0", "musu_npc1", "musu_npc2"} <= self.clues:
            return False
        if self.comparisons >= 3 or choice != ADS[self.comparisons][2]:
            return False
        self.comparisons += 1
        if self.comparisons == 3:
            self.completed.add("musu")
        return True

    def finish(self) -> bool:
        if self.portals_unlocked and set(PLANES) <= self.completed:
            self.finished = True
            return True
        return False

    def to_dict(self) -> dict:
        return {"version": 2, **{
            name: sorted(value) if isinstance(value, set) else value
            for name, value in vars(self).items()
        }}

    @classmethod
    def from_dict(cls, data: dict) -> Progress:
        if not isinstance(data, dict) or data.get("version") not in (1,2):
            raise ValueError("Unknown save format")
        p = cls()
        valid_clues = {"chart", "food", "wraps", "record1", "record2", "record3"}
        valid_clues |= {f"{plane}_npc{i}" for plane in PLANES for i in range(3)}
        for name, allowed in [("visited", set(PLANES)), ("completed", set(PLANES)),
                              ("clues", valid_clues), ("pairs", {"sea", "tree", "bird"})]:
            value = data.get(name, [])
            if not isinstance(value, list) or any(not isinstance(v, str) for v in value):
                raise ValueError("Invalid progress list")
            setattr(p, name, set(value) & allowed)
        for name in ("deliveries", "comparisons", "dream_round"):
            value = data.get(name, 0)
            if type(value) is not int or not 0 <= value <= 3:
                raise ValueError("Invalid puzzle progress")
            setattr(p, name, value)
        for name in ("ordered", "finished", "muted", "intro_seen", "met_sita"):
            value = data.get(name, False)
            if not isinstance(value, bool):
                raise ValueError("Invalid setting")
            setattr(p, name, value)
        # Reconcile milestones so an edited or interrupted save cannot open a
        # three-question puzzle at a nonexistent fourth question.
        if len(p.pairs) == 3:
            p.completed.add("frin")
        if p.deliveries == 3:
            p.completed.add("ansarac")
        if p.comparisons == 3:
            p.completed.add("musu")
        p.visited |= p.completed
        if p.dream_round:
            p.met_sita = True
        if p.met_sita:
            p.intro_seen = True
        p.finished = p.finished and p.portals_unlocked and set(PLANES) <= p.completed
        return p


class SaveStore:
    def __init__(self, directory: Path | None = None):
        base = Path(os.environ.get("LOCALAPPDATA", str(Path.home() / ".local" / "share")))
        self.directory = directory if directory is not None else base / "ChangingPlanes"
        self.path = self.directory / "journey.json"
        self.warning = ""

    def load(self) -> Progress:
        try:
            if sys.platform == "emscripten":
                import platform
                saved = platform.window.localStorage.getItem("changing-planes-journey-v2")
                return Progress.from_dict(json.loads(saved)) if saved else Progress()
            return Progress.from_dict(json.loads(self.path.read_text(encoding="utf-8")))
        except FileNotFoundError:
            return Progress()
        except (OSError, ValueError, TypeError):
            self.warning = "Your save could not be read. A fresh journey is ready."
            return Progress()

    def save(self, progress: Progress) -> bool:
        try:
            if sys.platform == "emscripten":
                import platform
                platform.window.localStorage.setItem("changing-planes-journey-v2", json.dumps(progress.to_dict()))
                self.warning = ""
                return True
            self.directory.mkdir(parents=True, exist_ok=True)
            temporary = self.path.with_suffix(".tmp")
            temporary.write_text(json.dumps(progress.to_dict(), indent=2), encoding="utf-8")
            temporary.replace(self.path)
            self.warning = ""
            return True
        except OSError:
            self.warning = "Progress could not be saved. This session still works."
            return False
