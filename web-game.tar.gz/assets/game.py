"""Changing Planes: a self-contained, local exploration game.

World coordinates are independent of the window size. Interaction, puzzle rules,
and drawing are kept separate so the project can be explained and changed.
"""
from __future__ import annotations

import math
import asyncio
import random
from array import array
from dataclasses import dataclass
from pathlib import Path

import pygame as pg

from art import emblem, rect, prop, INK, WHITE, GOLD, PAPER, STYLES
from retro import PixelFont, pixel_frame, character, app_icon
from world import Region, MAP_SIZE, VIEW_SIZE, SPAWN, LAYOUTS
from activities import DreamGame,PlaneGame
import story as narrative
from content import PLANES, FRAGMENTS, SUPPLIES, DELIVERIES, RECORDS, ADS, SOURCES
from model import Progress, SaveStore

WIDTH, HEIGHT = 1280, 800
WORLD = pg.Rect(0, 80, 960, 720)
PANEL = PAPER
MUTED = (83, 106, 118)


@dataclass
class Target:
    key: str
    name: str
    pos: tuple[int, int]
    kind: str


class Game:
    def __init__(self, save_dir: Path | None = None):
        pg.display.init()
        pg.font.init()
        self.window = pg.display.set_mode((1280, 800))
        pg.display.set_caption("Changing Planes Video Game")
        self.canvas = pg.Surface((WIDTH, HEIGHT))
        pg.display.set_icon(app_icon())
        self.clock = pg.time.Clock()
        self.fonts = {}
        self.regions = {key: Region(key) for key in ("hub", *PLANES)}
        self.maps = {key: region.background for key,region in self.regions.items()}
        self.view = pg.Surface(VIEW_SIZE)
        self.store = SaveStore(save_dir)
        self.progress = self.store.load()
        self.scene = "hub"
        self.pos = pg.Vector2(SPAWN)
        self.camera = pg.Vector2(0,0)
        self.facing = 'up'
        self.sprinting = False
        self.snap_camera()
        self.time = 0.0
        self.walking = False
        self.mode = "title"
        self.modal = None
        self.running = True
        self.buttons = []
        self.mouse = (-1, -1)
        self.selected_fragment = None
        self.sequence = []
        self.feedback = ""
        self.feedback_good = False
        self.toast = ""
        self.toast_time = 0.0
        self.journal_page = "frin"
        self.journal_note = 0
        self.fullscreen = False
        self.dialog_elapsed = 0.0
        self.dream_game = None
        self.plane_game = None
        self.sound = None
        try:
            pg.mixer.init(frequency=22050, size=-16, channels=1, buffer=512)
            samples = array("h", [int(1700*math.sin(2*math.pi*660*i/22050)*(1-i/4410)) for i in range(4410)])
            self.sound = pg.mixer.Sound(buffer=samples)
        except pg.error:
            pass  # Audio is optional; the whole game works without it.

    def font(self, size=24, bold=False):
        key = size, bold
        if key not in self.fonts:
            font = PixelFont(size,bold)
            self.fonts[key] = font
        return self.fonts[key]

    def text(self, message, x, y, size=24, color=WHITE, bold=False, center=False):
        img = self.font(size, bold).render(str(message), True, color)
        self.canvas.blit(img, (x-img.get_width()//2 if center else x, y))
        return img.get_height()

    def wrap(self, message, x, y, width, size=24, color=WHITE, gap=5):
        font = self.font(size)
        for paragraph in str(message).split("\n"):
            line = ""
            for word in paragraph.split():
                candidate = f"{line} {word}".strip()
                if font.size(candidate)[0] > width and line:
                    self.text(line, x, y, size, color)
                    y += font.get_height()+gap
                    line = word
                else:
                    line = candidate
            if line:
                self.text(line, x, y, size, color)
                y += font.get_height()+gap
            else:
                y += font.get_height()+gap
        return y

    def button(self, label, box, action, key=None, selected=False, enabled=True, detail=None):
        box=pg.Rect(box)
        hover=box.collidepoint(self.mouse) and enabled
        fill=(226,244,229) if hover or selected else PAPER if enabled else (225,229,212)
        pixel_frame(self.canvas,box,fill,(83,135,151) if hover or selected else (103,140,159),selected)
        offset=18
        if key:
            bw=max(28,self.font(16).size(key)[0]+12)
            rect(self.canvas,INK,(box.x+13,box.y+13,bw,27))
            self.text(key,box.x+13+bw//2,box.y+20,16,(255,250,214),center=True)
            offset=bw+25
        available=box.width-offset-17
        lines=self.wrapped_lines(label,available,22)
        y=box.y+17
        for line in lines[:2]:
            self.text(line,box.x+offset,y,22,WHITE if enabled else MUTED,True)
            y+=21
        if detail:
            self.wrap(detail,box.x+offset,max(box.y+45,y+3),available,20,MUTED,3)
        if enabled:
            self.buttons.append((box,action,key))

    def notify(self, message):
        self.toast, self.toast_time = message, 4.5

    def save(self):
        if not self.store.save(self.progress):
            self.notify(self.store.warning)

    def chime(self):
        if self.sound and not self.progress.muted:
            self.sound.play()

    def start(self):
        self.mode='play'
        self.scene='hub'
        self.pos.update(SPAWN)
        self.facing='up'
        self.snap_camera()
        if not self.progress.intro_seen:
            self.start_cutscene(narrative.opening(),self.finish_intro)
        if self.store.warning:
            self.notify(self.store.warning)

    def dialog(self, title, body, after=None):
        lines=self.wrapped_lines(body,WORLD.width-100,26)
        pages=['\n'.join(lines[i:i+3]) for i in range(0,len(lines),3)]
        self.modal = {"kind":"dialog","title":title,"body":body,"after":after,
                      "pages":pages or [''],"page":0,"revealed":0.0}

    def wrapped_lines(self,body,width,size):
        lines=[]
        font=self.font(size)
        for paragraph in body.split('\n'):
            if not paragraph:
                lines.append('')
                continue
            line=''
            for word in paragraph.split():
                candidate=(line+' '+word).strip()
                if line and font.size(candidate)[0]>width:
                    lines.append(line)
                    line=word
                else:
                    line=candidate
            lines.append(line)
        return lines

    def advance_dialog(self):
        if not self.modal or self.modal['kind']!='dialog':
            return
        page=self.modal['pages'][self.modal['page']]
        if self.modal['revealed']<len(page):
            self.modal['revealed']=float(len(page))
        elif self.modal['page']<len(self.modal['pages'])-1:
            self.modal['page']+=1
            self.modal['revealed']=0.0
        else:
            self.close()

    def close(self):
        was_cutscene=self.modal and self.modal.get('kind')=='cutscene'
        was_dream=self.modal and self.modal.get('kind')=='dream'
        after = self.modal.get("after") if self.modal else None
        self.modal = None
        self.feedback = ""
        if was_cutscene:
            self.snap_camera()
        if was_dream and self.progress.portals_unlocked and self.dream_game and not self.dream_game.done:
            self.dream_game.done=True
            after=self.unlock_portals
        if after:
            after()

    def start_cutscene(self,shots,after=None):
        self.modal={'kind':'cutscene','shots':shots,'index':0,'elapsed':0.0,'after':after}

    def advance_cutscene(self):
        if not self.modal or self.modal['kind']!='cutscene':
            return
        self.modal['index']+=1
        self.modal['elapsed']=0.0
        if self.modal['index']>=len(self.modal['shots']):
            self.close()

    def update_cutscene(self,dt):
        scene=self.modal
        shot=scene['shots'][scene['index']]
        scene['elapsed']+=dt
        if 'walk_to' in shot:
            difference=pg.Vector2(shot['walk_to'])-self.pos
            if difference.length()>3:
                self.sprinting=False
                self.move(difference,min(dt,difference.length()/170))
        focus=pg.Vector2(shot['focus'])
        w,h=self.regions[self.scene].size
        target=pg.Vector2(max(0,min(w-VIEW_SIZE[0],focus.x-VIEW_SIZE[0]/2)),
                          max(0,min(h-VIEW_SIZE[1],focus.y-VIEW_SIZE[1]/2)))
        self.camera+=(target-self.camera)*(1-math.exp(-2.8*dt))
        if scene['elapsed']>=shot['duration']:
            self.advance_cutscene()

    def finish_intro(self):
        self.progress.intro_seen=True
        self.save()
        self.notify('First task: speak with Sita Dulip.')

    def finish_lesson(self):
        self.progress.met_sita=True
        self.save()
        self.notify('New task: practice at the dream bench beside Sita.')

    def start_dream(self):
        if not self.progress.met_sita:
            self.dialog('The waiting bench','Sita Dulip is nearby. Ask her about changing planes before you begin to dream.')
        elif self.progress.portals_unlocked:
            self.dialog('A familiar dream','You have learned the method. The four portals are open. Bring four insights back to Sita.')
        else:
            self.dream_game=DreamGame(self)
            self.modal={'kind':'dream'}

    def unlock_portals(self):
        self.progress.dream_round=3
        self.save()
        self.start_cutscene(narrative.awakening())
        self.chime()

    def draw_cutscene(self):
        shot=self.modal['shots'][self.modal['index']]
        rect(self.canvas,(25,47,68),(0,80,960,65))
        self.text('CHANGING PLANES',24,103,22,(255,248,211))
        pixel_frame(self.canvas,(24,568,912,207))
        self.wrap(shot['title'],50,589,854,23,GOLD)
        self.wrap(shot['body'],50,637,854,23,WHITE,5)
        self.text('ENTER: NEXT SCENE   /   ESC: SKIP',50,750,16,MUTED)
        self.buttons.append((pg.Rect(24,568,912,207),self.advance_cutscene,None))

    def new_journey(self):
        self.progress = Progress(muted=self.progress.muted)
        self.save()
        self.modal = None
        self.start()

    def travel(self,destination):
        if destination in PLANES and not self.progress.portals_unlocked:
            task='Speak with Sita Dulip first.' if not self.progress.met_sita else 'Complete the three dream patterns at the bench beside Sita.'
            self.dialog('The portal is only a departure gate',task+' You have not learned to change planes yet.')
            return False
        self.modal=None
        self.scene=destination
        self.pos.update(SPAWN)
        self.facing='up'
        self.snap_camera()
        self.feedback=''
        if destination!='hub':
            fresh=destination not in self.progress.visited
            self.progress.visited.add(destination)
            self.save()
            if fresh:
                self.start_cutscene(narrative.arrival(destination))
        self.chime()
        return True

    def targets(self):
        region=self.regions[self.scene]
        layout=region.layout
        if self.scene=='hub':
            items=[Target(k,f"Gate {i+1} / {PLANES[k]['name']}",layout[k],'gate') for i,k in enumerate(PLANES)]
            items += [Target('desk','Travel journal desk',layout['desk'],'desk'),
                      Target('guide','Sita Dulip',layout['guide'],'guide'),
                      Target('dreambench','Dream bench',layout['dreambench'],'dreambench')]
        else:
            items=[Target(f'{self.scene}_npc{i}',name,layout[f'npc{i}'],'npc') for i,(name,_,_) in enumerate(PLANES[self.scene]['npcs'])]
            items.append(Target('hub','Return to airport',layout['hub'],'portal'))
            names={'frin':'Dream loom','ansarac':'Migration board','mahigul':'Archive table','musu':'Visitor kiosk'}
            items.append(Target('challenge',names[self.scene],layout['challenge'],'challenge'))
            if self.scene=='ansarac':
                items += [Target(k,name,layout[k],'supply') for k,name,_ in SUPPLIES if k not in self.progress.clues]
            if self.scene=='mahigul':
                items += [Target(k,name,layout[k],'record') for k,name,_,_ in RECORDS]
        items += [Target(r.key,r.name,tuple(r.pos),'ambient') for r in region.residents]
        items += [Target(f'sign{i}',name,pos,'sign') for i,(pos,name,_) in enumerate(region.signs)]
        return items

    def nearest(self):
        items = self.targets()
        target = min(items, key=lambda t:self.pos.distance_to(t.pos))
        return target if self.pos.distance_to(target.pos) < 78 else None

    def interact(self):
        target = self.nearest()
        if not target:
            self.notify("Walk closer to a person or a glowing marker, then press E.")
            return
        if target.kind in ("gate", "portal"):
            self.travel(target.key)
        elif target.kind == "guide":
            if not self.progress.met_sita:
                self.start_cutscene(narrative.lesson(),self.finish_lesson)
            elif not self.progress.portals_unlocked:
                self.dialog('Sita Dulip','The dream bench is beside me to the east. Watch the images, then repeat them in order. Three rounds will teach you the method. If a pattern slips away, you can try it again.')
            elif len(self.progress.completed)==4:
                self.modal={'kind':'reflection'}
            else:
                self.dialog('Sita Dulip',f'You have brought back {len(self.progress.completed)} of four insights. The portals can take you to the remaining planes. Help the people you meet, then tell me what you found.')
        elif target.kind=='dreambench':
            self.start_dream()
        elif target.kind == "desk":
            self.dialog('The travel journal',f'Insights collected: {len(self.progress.completed)}/4. Press J to reread your notes. When all four insights are yours, return to Sita Dulip beside the dream bench.')
        elif target.kind == "npc":
            index = int(target.key[-1])
            self.progress.collect(target.key)
            self.save()
            self.dialog(target.name, PLANES[self.scene]["npcs"][index][2])
        elif target.kind == 'ambient':
            resident=next(r for r in self.regions[self.scene].residents if r.key==target.key)
            self.dialog(resident.name,resident.body)
        elif target.kind == 'sign':
            entry=self.regions[self.scene].signs[int(target.key[4:])]
            self.dialog(entry[1],entry[2])
        elif target.kind == "supply":
            self.progress.collect(target.key)
            self.save()
            self.chime()
            self.notify(f"Packed: {target.name}. Check your journal with J.")
        elif target.kind == "record":
            self.progress.collect(target.key)
            self.save()
            record = next(r for r in RECORDS if r[0] == target.key)
            self.dialog(record[1], record[3]+"\n\nThis fictional record is now in your journal.")
        elif target.kind == "challenge":
            self.open_challenge()

    def open_challenge(self):
        if self.scene in self.progress.completed:
            self.dialog("Insight collected", PLANES[self.scene]["reflection"]+"\n\nYou can keep exploring, read your journal, or return to the airport with B.")
            return
        if self.scene in ('frin','ansarac','mahigul') and f'{self.scene}_npc0' not in self.progress.clues:
            self.dialog('Someone needs your help',self.objective())
            return
        if self.scene == "ansarac" and not {"chart","food","wraps"} <= self.progress.clues:
            missing = [name for key,name,_ in SUPPLIES if key not in self.progress.clues]
            self.dialog("Before the departure", "Gather these supplies first: "+", ".join(missing)+".\n\nLook for glowing parcels around the shelters. The travelers can explain what each supply is for.")
            return
        if self.scene == "mahigul" and not {"record1","record2","record3"} <= self.progress.clues:
            self.dialog("Read before deciding", "Examine the three glowing records along the bookshelves. Then return to this table to reconstruct their sequence.\n\nYou can reread collected records in your journal with J.")
            return
        if self.scene == "musu" and not {f"musu_npc{i}" for i in range(3)} <= self.progress.clues:
            missing = [PLANES["musu"]["npcs"][i][0] for i in range(3) if f"musu_npc{i}" not in self.progress.clues]
            self.dialog("Listen before comparing", "Speak with "+", ".join(missing)+" first. Their experiences will help you look beyond the advertisements.")
            return
        self.selected_fragment = None
        self.sequence = []
        self.feedback = ""
        self.plane_game=PlaneGame(self,self.scene)
        self.modal = {"kind":"puzzle"}

    def complete(self):
        self.chime()
        self.save()
        self.start_cutscene(narrative.reward(self.scene,len(self.progress.completed)))





    def interpret(self, index):
        if self.progress.interpret_archive(index):
            self.complete()
        else:
            self.feedback_good = False
            self.feedback = "Compare the agreement, the unconfirmed rumor, and the later speeches. What changed?"


    def finish(self,plane):
        if self.progress.finish():
            self.save()
            self.chime()
            self.start_cutscene(narrative.finale(),lambda:setattr(self,'modal',{'kind':'ending','plane':plane}))

    def toggle_mute(self):
        self.progress.muted = not self.progress.muted
        self.save()
        self.notify("Sound off" if self.progress.muted else "Sound on")

    def quit(self):
        self.save()
        self.mode = "title"
        self.modal = None

    def screen_to_canvas(self, pos):
        w,h = self.window.get_size()
        scale = min(w/WIDTH,h/HEIGHT)
        return ((pos[0]-(w-WIDTH*scale)/2)/scale,(pos[1]-(h-HEIGHT*scale)/2)/scale)

    def handle_event(self, event):
        if event.type == pg.QUIT:
            self.quit()
        elif event.type == pg.WINDOWFOCUSLOST and self.mode == "play" and not self.modal:
            self.modal = {"kind":"pause"}
        elif event.type == pg.MOUSEBUTTONDOWN and event.button == 1:
            point = self.screen_to_canvas(event.pos)
            self.mouse=point
            for box, action, _ in reversed(self.buttons):
                if box.collidepoint(point):
                    action()
                    break
        elif event.type == pg.KEYDOWN:
            if event.key == pg.K_F11:
                return
            if event.key == pg.K_m:
                self.toggle_mute()
                return
            if self.modal:
                kind = self.modal["kind"]
                if event.key == pg.K_ESCAPE:
                    self.close()
                    return
                if kind=='cutscene':
                    if event.key in (pg.K_e,pg.K_RETURN,pg.K_SPACE):
                        self.advance_cutscene()
                    return
                if kind=='dream':
                    self.dream_game.handle_key(event.key)
                    return
                if kind=='puzzle' and self.plane_game:
                    self.plane_game.handle_key(event.key)
                    return
                if kind == "dialog" and event.key in (pg.K_e,pg.K_RETURN,pg.K_SPACE):
                    self.advance_dialog()
                    return
                if kind == 'map' and event.key == pg.K_g:
                    self.close()
                    return
                if kind == "journal" and event.key == pg.K_j:
                    self.close()
                    return
                key = pg.key.name(event.key).upper()
                for _, action, shortcut in self.buttons:
                    if shortcut == key or (shortcut == "ENTER" and event.key == pg.K_RETURN):
                        action()
                        return
                return
            if self.mode == "title":
                if event.key in (pg.K_RETURN,pg.K_SPACE):
                    self.start()
                else:
                    key = pg.key.name(event.key).upper()
                    for _,action,shortcut in self.buttons:
                        if key == shortcut:
                            action()
                            return
                return
            if event.key == pg.K_ESCAPE:
                self.modal = {"kind":"pause"}
            elif event.key in (pg.K_e,pg.K_SPACE,pg.K_RETURN):
                self.interact()
            elif event.key == pg.K_j:
                self.journal_page = self.scene if self.scene in PLANES else "frin"
                self.journal_note = 0
                self.modal = {"kind":"journal"}
            elif event.key == pg.K_g:
                self.modal = {'kind':'map'}
            elif event.key == pg.K_b and self.scene != "hub":
                self.travel("hub")
            elif event.key == pg.K_TAB and self.scene == "hub":
                if self.progress.portals_unlocked:
                    self.modal = {"kind":"flights"}
                else:
                    self.dialog('No departures yet',self.objective())

    def obstacles(self):
        return self.regions[self.scene].solids

    def camera_target(self):
        w,h=self.regions[self.scene].size
        return pg.Vector2(max(0,min(w-VIEW_SIZE[0],self.pos.x-VIEW_SIZE[0]/2)),
                          max(0,min(h-VIEW_SIZE[1],self.pos.y-VIEW_SIZE[1]/2)))

    def snap_camera(self):
        self.camera.update(self.camera_target())

    def update_camera(self,dt):
        self.camera += (self.camera_target()-self.camera)*(1-math.exp(-12*dt))

    def to_screen(self,pos):
        return pg.Vector2(WORLD.x+(pos[0]-round(self.camera.x/2)*2)*2,
                          WORLD.y+(pos[1]-round(self.camera.y/2)*2)*2)

    def move(self,vector,dt):
        self.walking=vector.length_squared()>0
        if not self.walking:
            return
        self.facing=('right' if vector.x>0 else 'left') if abs(vector.x)>abs(vector.y) else ('down' if vector.y>0 else 'up')
        vector=vector.normalize()*(280 if self.sprinting else 170)*dt
        region=self.regions[self.scene]
        for axis in (0,1):
            proposed=self.pos.copy()
            proposed[axis]+=vector[axis]
            if region.can_stand(proposed):
                self.pos.update(proposed)

    def update(self,dt,keys=None):
        self.time+=dt
        self.toast_time=max(0,self.toast_time-dt)
        self.mouse=self.screen_to_canvas(pg.mouse.get_pos())
        self.walking=False
        if self.modal and self.modal['kind']=='cutscene':
            self.update_cutscene(dt)
            return
        if self.modal and self.modal['kind']=='dream' and self.dream_game:
            self.dream_game.update(dt)
        if self.modal and self.modal['kind']=='dialog':
            self.modal['revealed']+=dt*65
        if self.mode=='play' and not self.modal:
            keys=pg.key.get_pressed() if keys is None else keys
            self.sprinting=bool(keys[pg.K_LSHIFT] or keys[pg.K_RSHIFT])
            self.move(pg.Vector2(int(keys[pg.K_d] or keys[pg.K_RIGHT])-int(keys[pg.K_a] or keys[pg.K_LEFT]),
                                int(keys[pg.K_s] or keys[pg.K_DOWN])-int(keys[pg.K_w] or keys[pg.K_UP])),dt)
            self.regions[self.scene].update(dt,self.pos)
        elif self.mode=='title' and not self.modal:
            self.regions['hub'].update(dt,self.pos)
        self.update_camera(dt)

    def draw_world(self):
        region=self.regions[self.scene]
        camera=pg.Vector2(round(self.camera.x/2)*2,round(self.camera.y/2)*2)
        view_rect=pg.Rect(camera,VIEW_SIZE)
        self.view.blit(region.background,(0,0),view_rect)
        # A few animated wave crests, with shore foam already baked into tiles.
        for y in range(max(0,view_rect.top//32),min(region.rows,view_rect.bottom//32+1)):
            for x in range(max(0,view_rect.left//32),min(region.cols,view_rect.right//32+1)):
                if region.grid[y][x]=='water' and (x+y)%3==0:
                    xx=x*32-camera.x+int(math.sin(self.time*1.8+y)*4)
                    yy=y*32-camera.y+14
                    pg.draw.line(self.view,(155,225,230),(xx+6,yy),(xx+19,yy),2)
        actors=[]
        for item in region.scenery:
            if item.rect.colliderect(view_rect.inflate(150,180)):
                actors.append((item.depth,item.image,item.rect.topleft))
        targets=self.targets()
        for target in targets:
            x,y=target.pos
            if not view_rect.inflate(160,160).collidepoint(x,y):
                continue
            if target.kind in ('npc','guide','ambient'):
                variant=(int(target.key[-1])+2) if target.kind=='npc' else 5
                facing='down'
                walking=False
                if target.kind=='ambient':
                    resident=next(r for r in region.residents if r.key==target.key)
                    variant,facing,walking=resident.variant,resident.direction,resident.walking
                elif self.pos.distance_to(target.pos)<100:
                    dx,dy=self.pos-pg.Vector2(target.pos)
                    facing=('right' if dx>0 else 'left') if abs(dx)>abs(dy) else ('down' if dy>0 else 'up')
                step=(1+int(self.time*7)%2) if walking else 0
                image=character(variant,facing,step)
                actors.append((y,image,(x-20,y-48)))
            elif target.kind=='portal' or (target.kind=='gate' and self.progress.portals_unlocked):
                surf=pg.Surface((68,84),pg.SRCALPHA)
                pg.draw.ellipse(surf,(80,122,151),(4,62,60,18))
                pg.draw.ellipse(surf,(228,237,217),(12,3,45,72),4)
                pg.draw.ellipse(surf,(90,162,198),(18,10,33,57),3)
                pg.draw.ellipse(surf,(178,225,225),(23,17,23,43),2)
                actors.append((y,surf,(x-34,y-70)))
            elif target.kind in ('supply','record'):
                surf=pg.Surface((42,36),pg.SRCALPHA)
                if target.kind=='supply':
                    rect(surf,(99,83,65),(5,8,32,25));rect(surf,(235,177,91),(7,10,28,21))
                    rect(surf,(255,234,153),(18,10,5,21));rect(surf,(255,234,153),(7,16,28,4))
                else:
                    rect(surf,(81,100,110),(2,10,38,23));rect(surf,(255,243,198),(4,8,34,22))
                    rect(surf,(160,147,123),(20,10,2,18))
                actors.append((y+2,surf,(x-21,y-28)))
            if target.kind in ('npc','gate','challenge','supply','record','guide','dreambench'):
                done=(target.kind=='npc' and target.key in self.progress.clues) or (target.kind=='record' and target.key in self.progress.clues) or (target.kind=='gate' and target.key in self.progress.completed) or (target.kind=='challenge' and self.scene in self.progress.completed)
                if target.kind=='guide':
                    done=self.progress.met_sita
                if target.kind=='dreambench':
                    done=self.progress.portals_unlocked
                mark=pg.Surface((14,18),pg.SRCALPHA)
                rect(mark,(58,80,96),(1,1,12,13));rect(mark,(255,232,149) if not done else (175,229,186),(2,2,10,11))
                if target.kind=='gate' and not self.progress.portals_unlocked:
                    rect(mark,(96,111,123),(2,2,10,11))
                    rect(mark,(225,230,213),(5,6,5,5))
                    rect(mark,(225,230,213),(6,3,3,5),0,1)
                elif done:
                    pg.draw.lines(mark,(54,110,105),False,[(3,7),(6,10),(11,4)],2)
                else:
                    rect(mark,(109,88,68),(6,4,2,4));rect(mark,(109,88,68),(6,9,2,1))
                pg.draw.polygon(mark,(58,80,96),[(5,14),(9,14),(7,17)])
                bob=int(math.sin(self.time*3+x)*2)
                actors.append((y+90,mark,(x-7,y-(68 if target.kind in ('npc','guide') else 48)+bob)))
        step=(1+int(self.time*(12 if self.sprinting else 8))%2) if self.walking else 0
        actors.append((self.pos.y,character(0,self.facing,step,True),(self.pos.x-20,self.pos.y-48)))
        for _,image,point in sorted(actors,key=lambda item:item[0]):
            self.view.blit(image,(round(point[0]-camera.x),round(point[1]-camera.y)))
        # Wingbeats and floating motes are in world coordinates, not screen space.
        for i in range(10):
            x=(i*211+210+math.sin(self.time*.5+i)*24)%MAP_SIZE[0]
            y=(i*173+320+math.cos(self.time*.8+i)*13)%MAP_SIZE[1]
            if view_rect.collidepoint(x,y):
                xx,yy=int(x-camera.x),int(y-camera.y)
                color=(249,218,135) if self.scene=='frin' else (255,236,169)
                pg.draw.line(self.view,color,(xx-3,yy-2 if int(self.time*7)%2 else yy+2),(xx,yy),2)
                pg.draw.line(self.view,color,(xx,yy),(xx+3,yy-2 if int(self.time*7)%2 else yy+2),2)
        self.canvas.blit(pg.transform.scale(self.view,WORLD.size),WORLD)
        if self.mode=='play' and not self.modal:
            near=self.nearest()
            if near:
                label='E  '+near.name
                w=min(WORLD.width-40,self.font(24).size(label)[0]+44)
                pixel_frame(self.canvas,(WORLD.centerx-w//2,728,w,50))
                self.text(label,WORLD.centerx,745,24,WHITE,center=True)
            self.draw_waypoint()

    def objective(self):
        p=self.progress
        if self.scene=='hub':
            if not p.met_sita:
                return 'Find Sita Dulip by the waiting area. Press E to speak with her.'
            if not p.portals_unlocked:
                return f'Use the dream bench beside Sita. Remember three patterns: {p.dream_round}/3 complete.'
            if len(p.completed)==4:
                return 'Bring your four insights back to Sita Dulip at the airport.'
            return 'Explore any unlocked plane. Help its residents to earn an insight.'
        if self.scene in p.completed:
            return 'Insight secured! Press B to return to the airport and continue your journey.'
        if self.scene in ('frin','ansarac','mahigul') and f'{self.scene}_npc0' not in p.clues:
            name={'frin':'Iri','ansarac':'the route keeper','mahigul':'the archivist'}[self.scene]
            return 'Speak with '+name+' to learn what needs your help.'
        if self.scene=='frin':
            return f'Enter the dream loom. Navigate the maze and reunite the images: {len(p.pairs)}/3 pairs.'
        if self.scene=='ansarac':
            count=sum(k in p.clues for k,_,_ in SUPPLIES)
            return f'Gather supplies: {count}/3. '+('Pack a balanced cart at the migration board.' if count==3 else 'Find the gold parcels around the shelters.')
        if self.scene=='mahigul':
            count=sum(k in p.clues for k,_,_,_ in RECORDS)
            return f'Recover records: {count}/3. '+('Rebuild the timeline at the archive table.' if count==3 else 'Read the three library collections.')
        count=sum(f'musu_npc{i}' in p.clues for i in range(3))
        return f'Listen to islanders: {count}/3. '+('Connect claims to evidence at the visitor kiosk.' if count==3 else 'Find the fisher, hotel worker, and elder.')

    def draw_hud(self):
        rect(self.canvas,PAPER,(0,0,1280,80))
        rect(self.canvas,(64,107,132),(0,76,1280,4))
        self.text('Changing Planes Video Game',23,14,24,INK,True)
        name="Airport / Sita Dulip's method" if self.scene=='hub' else PLANES[self.scene]['name']
        self.text(name,24,48,18,MUTED)
        self.text('INSIGHTS',647,17,18,GOLD)
        self.text(f'{len(self.progress.completed)} / 4',647,45,20,WHITE)
        for i,key in enumerate(PLANES):
            pg.draw.circle(self.canvas,(64,122,145) if key in self.progress.completed else (181,197,189),(814+i*36,34),12)
            self.text(str(i+1),814+i*36,27,16,PAPER if key in self.progress.completed else (111,134,142),center=True)
        self.draw_quest_panel()

    def quest_steps(self):
        p=self.progress
        if self.scene=='hub':
            if not p.portals_unlocked:
                return [(p.met_sita,'Meet Sita Dulip'),(p.dream_round>=1,'Dream pattern 1'),
                        (p.dream_round>=2,'Dream pattern 2'),(p.dream_round>=3,'Dream pattern 3'),
                        (p.portals_unlocked,'Reveal four portals')]
            return [(key in p.completed,PLANES[key]['name']+' insight') for key in PLANES]+[(p.finished,'Return to Sita')]
        key=self.scene
        if key=='frin':
            return [(f'{key}_npc0' in p.clues,'Speak with Iri'),
                    (len(p.pairs)>=1,'Connect dream 1'),(len(p.pairs)>=2,'Connect dream 2'),
                    (len(p.pairs)==3,'Connect dream 3')]
        if key=='ansarac':
            return [(f'{key}_npc0' in p.clues,'Meet route keeper'),('chart' in p.clues,'Find route chart'),
                    ('food' in p.clues,'Find provisions'),('wraps' in p.clues,'Find warm wraps'),
                    (key in p.completed,'Pack balanced cart')]
        if key=='mahigul':
            return [(f'{key}_npc0' in p.clues,'Meet the archivist')]+[(f'record{i}' in p.clues,f'Read record {i}') for i in range(1,4)]+[(p.ordered,'Rebuild the timeline'),(key in p.completed,'Explain the evidence')]
        return [(f'musu_npc{i}' in p.clues,'Hear '+name) for i,name in enumerate(('the fisher','hotel worker','the elder'))]+[(key in p.completed,'Connect the evidence')]

    def draw_quest_panel(self):
        pixel_frame(self.canvas,(960,80,320,720))
        self.text('CURRENT OBJECTIVE',982,105,20,GOLD)
        title=('Learn to change planes' if not self.progress.portals_unlocked else 'Four insights to find') if self.scene=='hub' else PLANES[self.scene]['subtitle']
        y=self.wrap(title,982,148,268,23,WHITE,3)
        y=self.wrap(self.objective(),982,y+17,268,21,MUTED,4)+19
        for done,label in self.quest_steps():
            rect(self.canvas,(78,137,127) if done else (177,195,185),(983,y,14,14),0,0 if done else 2)
            if done:
                pg.draw.lines(self.canvas,PAPER,False,[(985,y+7),(989,y+11),(995,y+3)],2)
            y=self.wrap(label,1007,y,242,18,WHITE if not done else (75,125,113),2)+13
        pg.draw.line(self.canvas,(159,188,188),(982,652),(1257,652),2)
        self.text('THE JOURNEY HOME',982,675,18,GOLD)
        self.text(f'{len(self.progress.completed)} / 4 INSIGHTS',982,707,22,WHITE)
        self.text('E: TALK   G: MAP',982,750,16,MUTED)
        self.text('J: JOURNAL  SHIFT: RUN',982,775,16,MUTED)

    def next_target(self):
        targets=self.targets()
        p=self.progress
        if self.scene=='hub':
            keys=['guide'] if not p.met_sita or len(p.completed)==4 else ['dreambench'] if not p.portals_unlocked else [k for k in PLANES if k not in p.completed]
        elif self.scene in p.completed:
            keys=['hub']
        elif self.scene in ('frin','ansarac','mahigul') and f'{self.scene}_npc0' not in p.clues:
            keys=[f'{self.scene}_npc0']
        elif self.scene=='ansarac':
            keys=[key for key,_,_ in SUPPLIES if key not in p.clues] or ['challenge']
        elif self.scene=='mahigul':
            keys=[key for key,_,_,_ in RECORDS if key not in p.clues] or ['challenge']
        elif self.scene=='musu':
            keys=[f'musu_npc{i}' for i in range(3) if f'musu_npc{i}' not in p.clues] or ['challenge']
        else:
            keys=['challenge']
        relevant=[target for target in targets if target.key in keys]
        return min(relevant,key=lambda t:self.pos.distance_to(t.pos)) if relevant else None

    def draw_waypoint(self):
        target=self.next_target()
        if not target:
            return
        point=self.to_screen(target.pos)
        if WORLD.inflate(-64,-140).collidepoint(point):
            return
        direction=point-pg.Vector2(WORLD.center)
        if direction.length_squared()==0:
            return
        direction=direction.normalize()
        x=max(45,min(WORLD.right-45,point.x))
        y=max(130,min(680,point.y))
        # The label sits inside the screen; a tiny arrow points beyond it.
        label=target.name.split(' / ')[-1]
        tw=self.font(18).size(label)[0]
        x=max(tw/2+20,min(WORLD.right-20-tw/2,x))
        pixel_frame(self.canvas,(int(x-tw/2-10),int(y-18),tw+20,42))
        self.text(label,int(x),int(y-3),18,WHITE,center=True)
        tip=pg.Vector2(x,y-29)
        side=pg.Vector2(-direction.y,direction.x)
        pg.draw.polygon(self.canvas,(248,217,111),[tip+direction*9,tip-direction*6+side*6,tip-direction*6-side*6])

    def draw_dialog_box(self):
        dialog=self.modal
        box=(26,548,WORLD.width-52,228)
        pixel_frame(self.canvas,box)
        self.text(dialog['title'],58,570,25,GOLD,True)
        page=dialog['pages'][dialog['page']]
        visible=page[:int(dialog['revealed'])]
        for i,line in enumerate(visible.split('\n')):
            self.text(line,58,612+i*30,26,WHITE)
        count=f"{dialog['page']+1}/{len(dialog['pages'])}"
        self.text(count,62,748,16,MUTED)
        self.text('E / ENTER',WORLD.right-210,748,16,GOLD)
        if int(self.time*3)%2==0:
            pg.draw.polygon(self.canvas,(55,110,139),[(WORLD.right-89,743),(WORLD.right-73,743),(WORLD.right-81,753)])
        self.buttons.append((pg.Rect(box),self.advance_dialog,None))

    def draw_region_map(self):
        self.shell('A little farther to wander','REGION MAP / GOLD = LANDMARK / RED = YOU',(100,70,1080,660))
        region=self.regions[self.scene]
        r=pg.Rect(143,224,576,432)
        pixel_frame(self.canvas,r.inflate(16,16))
        self.canvas.blit(pg.transform.scale(region.minimap,r.size),r)
        for i,(name,pos) in enumerate(region.landmarks):
            x=r.x+int(pos[0]/MAP_SIZE[0]*r.w)
            y=r.y+int(pos[1]/MAP_SIZE[1]*r.h)
            rect(self.canvas,INK,(x-10,y-10,22,22))
            rect(self.canvas,(252,220,129),(x-8,y-8,18,18))
            self.text(str(i+1),x+1,y-3,16,WHITE,center=True)
            self.text(f'{i+1}. {name}',759,245+i*42,20,WHITE)
        cx=r.x+int(self.pos.x/MAP_SIZE[0]*r.w)
        cy=r.y+int(self.pos.y/MAP_SIZE[1]*r.h)
        pg.draw.circle(self.canvas,(255,253,221),(cx,cy),8)
        pg.draw.circle(self.canvas,(218,83,85),(cx,cy),5)
        view=pg.Rect(r.x+self.camera.x/MAP_SIZE[0]*r.w,r.y+self.camera.y/MAP_SIZE[1]*r.h,
                     VIEW_SIZE[0]/MAP_SIZE[0]*r.w,VIEW_SIZE[1]/MAP_SIZE[1]*r.h)
        pg.draw.rect(self.canvas,(255,252,221),view,2)
        self.text('SHIFT: RUN   /   E: TALK   /   G: CLOSE MAP',151,690,20,GOLD)

    def shell(self,title,kicker="TRAVELER'S FIELD NOTES",box=(130,110,1020,600)):
        shade=pg.Surface((WIDTH,HEIGHT),pg.SRCALPHA)
        shade.fill((25,50,71,155))
        self.canvas.blit(shade,(0,0))
        pixel_frame(self.canvas,box)
        x,y,w,h=box
        self.text(kicker,x+30,y+23,16,GOLD,True)
        self.text(title,x+30,y+55,33,WHITE,True)
        self.button('Close',(x+w-157,y+17,138,53),self.close,'ESC')
        pg.draw.line(self.canvas,(168,195,195),(x+30,y+108),(x+w-30,y+108),2)

    def draw_title(self):
        self.draw_world()
        rect(self.canvas,(213,231,218),(960,80,320,720))
        pixel_frame(self.canvas,(62,58,680,680))
        self.text('CHANGING',104,132,66,INK,True)
        self.text('PLANES',104,207,76,(46,125,153),True)
        self.text('VIDEO GAME',106,303,33,(177,105,84),True)
        self.wrap('Learn to travel. Help four worlds. Bring their stories home.',106,367,582,27,WHITE)
        self.wrap('Begin at the airport. Find Sita Dulip and discover what lies beyond an ordinary departure gate.',106,433,582,24,MUTED)
        continuing=self.progress.intro_seen or bool(self.progress.visited)
        self.button('Continue journey' if continuing else 'Begin journey',(106,525,588,60),self.start,'ENTER')
        self.button('New game',(106,604,292,57),lambda:setattr(self,'modal',{'kind':'reset'}),'N')
        self.button('About',(414,604,280,57),lambda:setattr(self,'modal',{'kind':'about'}),'A')
        self.text('YOUR FIRST TASK: FIND SITA DULIP',106,697,18,GOLD)
        pixel_frame(self.canvas,(784,58,432,680))
        self.text('HOW TO PLAY',816,91,27,GOLD)
        instructions=[('WASD / ARROWS','Walk around the world'),('SHIFT','Hold to run'),('E / ENTER','Talk, use, or continue'),('G','Open the region map'),('J','Read your quest journal'),('B','Return to the airport'),('TAB','Airport portal board'),('ESC','Pause or close a window'),('F11 / M','Fullscreen / sound')]
        y=149
        for keys,label in instructions:
            self.text(keys,816,y,18,GOLD)
            self.text(label,816,y+24,20,WHITE)
            y+=52
        self.wrap('Watch the side panel for your task. Each plane has a different minigame. Esc skips story scenes.',816,633,365,20,MUTED,3)

    def draw_modal(self):
        kind=self.modal["kind"]
        if kind=="dialog":
            self.draw_dialog_box()
        elif kind=='cutscene':
            self.draw_cutscene()
        elif kind=='dream':
            self.dream_game.draw()
        elif kind=='map':
            self.draw_region_map()
        elif kind=="puzzle":
            self.draw_puzzle()
        elif kind=="flights":
            self.shell("Where will you go?","PORTAL BOARD")
            for i,(key,plane) in enumerate(PLANES.items()):
                self.button(plane["name"],(180,247+i*99,920,83),lambda k=key:self.travel(k),str(i+1),enabled=self.progress.portals_unlocked,detail=plane["theme"] if self.progress.portals_unlocked else "Learn Sita's method to reveal this portal.")
        elif kind=="pause":
            self.shell("A moment in between","PAUSED")
            self.button("Resume journey",(180,250,440,60),self.close,"ENTER")
            self.button("Read your journal",(640,250,460,60),lambda:setattr(self,"modal",{"kind":"journal"}),"J")
            self.button("About & sources",(180,331,440,60),lambda:setattr(self,"modal",{"kind":"about"}),"A")
            self.button("Start a new journey",(640,331,460,60),lambda:setattr(self,"modal",{"kind":"reset"}),"N")
            self.button("Save and title screen",(180,412,440,60),self.quit,"Q")
            self.wrap("WASD / arrows: walk. Shift: run. E: talk. G: map. J: journal. B: airport. Tab: airport flight board. F11: fullscreen. M: sound.\n\nProgress saves after discoveries and puzzle steps.",180,510,900,24,MUTED)
        elif kind=="reset":
            self.shell("Start over?","NEW JOURNEY")
            self.wrap("This replaces your saved story, insights, clues, and puzzle progress in this browser.",180,267,880,28)
            self.button("Keep my journey",(180,403,440,65),self.close,"ESC")
            self.button("Start fresh",(640,403,460,65),self.new_journey,"N")
        elif kind=="journal":
            self.draw_journal()
        elif kind=="about":
            self.shell("About the game","CHANGING PLANES VIDEO GAME")
            y=self.wrap("An exploration game inspired by Ursula K. Le Guin's Changing Planes. Learn to travel with Sita Dulip, help four worlds, and bring their insights home. Dialogue, dream training, challenges, and archive records are original game adaptations.",180,246,900,25,MUTED)
            y=self.wrap("The story scenes and dream training are imaginative game mechanics, not quotations from the book. Artwork, lettering, and sound are generated in Python.",180,y+12,900,24,MUTED)
            for label,description,url in SOURCES:
                y+=17
                self.text(label.upper(),180,y,18,GOLD,True)
                y=self.wrap(description,180,y+23,900,23)
                y=self.wrap(url,180,y+1,900,20,MUTED)
        elif kind=="reflection":
            self.shell("What will you carry home?","SITA DULIP / FOUR INSIGHTS")
            self.wrap("Sita asks which insight changed the way you see. Choose what you want to tell her. There is no wrong answer.",180,249,880,27,MUTED)
            for i,(key,plane) in enumerate(PLANES.items()):
                self.button(plane["theme"],(180,338+i*76,920,61),lambda k=key:self.finish(k),str(i+1))
        elif kind=="ending":
            self.shell("The journey stays with you","JOURNEY COMPLETE")
            for i,key in enumerate(PLANES):
                emblem(self.canvas,(280+i*240,285),key,PLANES[key]["color"],30)
            self.wrap(PLANES[self.modal["plane"]]["reflection"],180,349,900,24,WHITE,6)
            self.wrap("You learned to change planes, helped four communities, and brought their stories home. Your journey is complete. The worlds remain open if you would like to visit again.",180,469,900,25,MUTED)
            self.button("Keep exploring",(180,605,440,60),self.close,"ENTER")
            self.button("Save and quit",(640,605,460,60),self.quit,"Q")

    def draw_journal(self):
        self.shell("A passport of perspectives","YOUR JOURNAL",(110,60,1060,680))
        for i,(key,plane) in enumerate(PLANES.items()):
            self.button(plane["name"],(145+i*249,187,239,55),lambda k=key:self.select_journal(k),str(i+1),key==self.journal_page)
        key=self.journal_page
        plane=PLANES[key]
        done=key in self.progress.completed
        self.text("INSIGHT EARNED" if done else "IN PROGRESS" if key in self.progress.visited else "NOT YET VISITED",150,263,18,GOLD,True)
        self.wrap(plane["reflection"] if done else plane["objective"],150,291,970,24,WHITE)
        self.text("COLLECTED NOTES",150,404,18,GOLD,True)
        notes=[]
        if key=="mahigul":
            notes=[(title,body) for clue,title,_,body in RECORDS if clue in self.progress.clues]
        else:
            notes=[(name,body) for i,(name,_,body) in enumerate(plane["npcs"]) if f"{key}_npc{i}" in self.progress.clues]
        if notes:
            self.journal_note=min(self.journal_note,len(notes)-1)
            title,body=notes[self.journal_note]
            self.text(title,150,449,25,GOLD,True)
            self.wrap(body,150,491,970,24,MUTED,5)
            self.text(f'NOTE {self.journal_note+1} / {len(notes)}',580,646,18,GOLD)
            self.button('Previous',(150,628,280,54),lambda:self.turn_note(-1),'LEFT',enabled=self.journal_note>0)
            self.button('Next',(837,628,280,54),lambda:self.turn_note(1),'RIGHT',enabled=self.journal_note<len(notes)-1)
        else:
            self.wrap("Talk to residents and investigate the gold markers to add notes here.",150,449,940,24,MUTED)
        if key=="ansarac":
            packed=[name for clue,name,_ in SUPPLIES if clue in self.progress.clues]
            if packed:
                self.text("PACKED: "+" / ".join(packed),150,697,20,GOLD)

    def select_journal(self,key):
        self.journal_page=key
        self.journal_note=0

    def turn_note(self,delta):
        self.journal_note=max(0,self.journal_note+delta)

    def draw_feedback(self):
        if self.feedback:
            self.wrap(self.feedback,180,642,910,23,(43,122,104) if self.feedback_good else (160,91,55))

    def draw_puzzle(self):
        if self.plane_game is not None:
            self.plane_game.draw()

    def draw(self):
        self.buttons=[]
        self.canvas.fill(INK)
        if self.mode=="title":
            self.draw_title()
        else:
            self.draw_hud()
            self.draw_world()
        if self.modal:
            # Background controls must never receive modal clicks or shortcuts.
            self.buttons=[]
            self.draw_modal()
        if self.toast_time>0 and not self.modal:
            tw=self.font(23).size(self.toast)[0]
            pixel_frame(self.canvas,(WIDTH//2-tw//2-18,85,tw+36,43))
            self.text(self.toast,WIDTH//2,100,23,GOLD,center=True)
        w,h=self.window.get_size()
        scale=min(w/WIDTH,h/HEIGHT)
        size=(max(1,int(WIDTH*scale)),max(1,int(HEIGHT*scale)))
        image=pg.transform.scale(self.canvas,size) if size!=(WIDTH,HEIGHT) else self.canvas
        self.window.fill((12,19,29))
        self.window.blit(image,((w-size[0])//2,(h-size[1])//2))
        pg.display.flip()

    async def run(self, frames=None):
        count=0
        while self.running:
            dt=min(self.clock.tick(60)/1000,0.05)
            # Build hit regions before processing the next batch of input events.
            self.draw()
            for event in pg.event.get():
                self.handle_event(event)
            self.update(dt)
            await asyncio.sleep(0)
            count+=1
            if frames is not None and count>=frames:
                break
        pg.quit()
