"""Original scenes for this interpretive game adaptation."""
from world import LAYOUTS,SPAWN

INSIGHTS={
 'frin':('The dream thread','Connect what different people imagine.'),
 'ansarac':('The journey ribbon','Help a community prepare to move.'),
 'mahigul':('The archive page','Discover how a shared agreement broke down.'),
 'musu':('The island postcard','Look beyond what a brochure promises.'),
}
ARRIVALS={
 'frin':('A dream with missing pieces','Find Iri, then navigate the shared dream to reunite three pairs of images.'),
 'ansarac':('Before the crossing','Meet the route keeper, gather three supplies, and pack a cart that can travel safely.'),
 'mahigul':('The story before the story','Meet the archivist, recover three records, and reconstruct how a shared agreement broke down.'),
 'musu':('Welcome to paradise?','Find three islanders and connect their experiences to the advertising promises they challenge.'),
}
THANKS={
 'frin':('Iri','The images have found one another. Take this dream thread: a shared story can still hold different voices.'),
 'ansarac':('The route keeper','The load is ready and the cart is balanced. Take this journey ribbon. You listened to what the travelers needed.'),
 'mahigul':('The archivist','The records are back in conversation. Take this archive page. Ask what happened before a story became certain.'),
 'musu':('The elder','You looked beyond the brochure. Take this postcard, with room for the islanders to tell their own story.'),
}

def shot(title,body,focus,duration=5,**extra):
    return dict(title=title,body=body,focus=focus,duration=duration,**extra)

def opening():
    return [shot('PROLOGUE / A FLIGHT THAT NEVER LEAVES','Another delay. Another announcement. You came here to catch an airplane. For now, all you can do is wait.',SPAWN,5,walk_to=(1152,1392)),
      shot('SOMEONE SEES ANOTHER WAY','A traveler named Sita Dulip watches the terminal as though she can see something just beyond it.',LAYOUTS['hub']['guide']),
      shot('YOUR FIRST STEP','Find Sita Dulip beside the waiting area. She may know how to travel without boarding a flight.',SPAWN,4)]

def lesson():
    return [shot("SITA DULIP'S METHOD",'Sita: An airport is a place between places. Let the announcements fade. Notice the images that arrive when your attention wanders.',LAYOUTS['hub']['guide']),
      shot('THE DREAM BENCH','Sita: Sit at the bench beside me. Watch a short sequence of images, then bring them back in the same order. We will practice three times.',LAYOUTS['hub']['dreambench'])]

def awakening():
    result=[shot('THE TERMINAL CHANGES','The dream holds. Ordinary departures become openings into other ways of living. All four portals are now available.',LAYOUTS['hub']['dreambench'],4)]
    for plane,label in [('frin','Frin / shared dreams'),('ansarac','Ansarac / a seasonal journey'),('mahigul','Mahigul / an unfinished archive'),('musu','Musu Sum / beyond the brochure')]:
        result.append(shot('PORTAL OPEN / '+label.upper(),'You can explore these four planes in any order.',LAYOUTS['hub'][plane],2.6))
    result.append(shot('A REASON TO GO','Sita: Bring back four insights, one from each plane. Help its residents, learn what matters to them, then return and tell me what you found.',LAYOUTS['hub']['guide'],6))
    return result

def arrival(plane):
    title,body=ARRIVALS[plane]
    return [shot(title.upper(),body,LAYOUTS[plane]['npc0']),
      shot('YOUR TASK IS IN THE SIDE PANEL','Follow the gold markers or press G for your map. Other residents have optional conversations.',SPAWN,3.5)]

def reward(plane,count):
    name,body=THANKS[plane]
    end='All four insights are yours. Return to the airport and speak with Sita Dulip.' if count==4 else 'Press B to return to the airport when you are ready for another plane.'
    return [shot(name.upper(),body,LAYOUTS[plane]['challenge'],6),
      shot(f'INSIGHT EARNED / {count} OF 4',INSIGHTS[plane][0]+'. '+end,SPAWN,4)]

def finale():
    return [shot('BACK WHERE YOU BEGAN','The airport looks familiar. You carry a dream thread, a journey ribbon, an archive page, and an island postcard: four things you could not have packed before you left.',LAYOUTS['hub']['guide'],6),
      shot('SITA DULIP','You found more than destinations. You listened to people whose lives do not fit into a single familiar story. That is something worth bringing home.',LAYOUTS['hub']['guide'],6)]
