"""Original bitmap lettering and pixel sprites; no external font/assets needed."""
from functools import lru_cache
import pygame as pg

# Each character is a little 5x7 bitmap, written in hexadecimal rows.
GLYPHS = {
    'A':'0E11111F111111','B':'1E11111E11111E','C':'0E11101010110E',
    'D':'1E11111111111E','E':'1F10101E10101F','F':'1F10101E101010',
    'G':'0E11101711110F','H':'1111111F111111','I':'0E04040404040E',
    'J':'0702020202120C','K':'11121418141211','L':'1010101010101F',
    'M':'111B1515111111','N':'11191513111111','O':'0E11111111110E',
    'P':'1E11111E101010','Q':'0E11111115120D','R':'1E11111E141211',
    'S':'0F10100E01011E','T':'1F040404040404','U':'1111111111110E',
    'V':'11111111110A04','W':'11111115151B11','X':'11110A040A1111',
    'Y':'11110A04040404','Z':'1F01020408101F',
    'a':'00000E010F110F','b':'10101E1111111E','c':'00000F1010100F',
    'd':'01010F1111110F','e':'00000E111F100E','f':'0609081C080808',
    'g':'00000F110F010E','h':'10101E11111111','i':'04000C0404040E',
    'j':'0200060202120C','k':'101011121C1211','l':'0C04040404040E',
    'm':'00001A15151515','n':'00001E11111111','o':'00000E1111110E',
    'p':'00001E111E1010','q':'00000F110F0101','r':'00001619101010',
    's':'00000F100E011E','t':'08081C08080906','u':'0000111111130D',
    'v':'00001111110A04','w':'00001115151B11','x':'0000110A040A11',
    'y':'000011110F010E','z':'00001F0204081F',
    '0':'0E11131519110E','1':'040C040404040E','2':'0E11010204081F',
    '3':'1E01010601011E','4':'02060A121F0202','5':'1F10101E01011E',
    '6':'0E10101E11110E','7':'1F010204080808','8':'0E11110E11110E',
    '9':'0E11110F01010E',' ':'00000000000000',
    '.':'00000000000C0C',',':'00000000000C08',':':'000C0C000C0C00',
    ';':'000C0C000C0C08','!':'04040404040004','?':'0E110102040004',
    "'":'04040800000000','"':'0A0A0000000000','-':'0000001F000000',
    '/':'01010204081010','+':'0004041F040400','(':'02040808080402',
    ')':'08040202020408','[':'0E08080808080E',']':'0E02020202020E',
    '&':'0C12140C15120D','=':'00001F001F0000','_':'0000000000001F',
    '%':'191A0204080B13','<':'02040810080402','>':'08040201020408',
    '|':'04040404040404','*':'00150E1F0E1500','#':'0A1F0A0A1F0A00',
    '@':'0E11171B17100E', '\\':'10100804020101',
}


class PixelFont:
    def __init__(self,size=24,bold=False):
        self.scale=max(1,round(size/11))
        self.bold=bold
        self.advance=6*self.scale

    def size(self,message):
        return (max(1,len(str(message))*self.advance-self.scale),self.get_height())

    def get_height(self):
        return 9*self.scale

    def render(self,message,antialias,color):
        result=pg.Surface(self.size(message),pg.SRCALPHA)
        for i,char in enumerate(str(message)):
            char={'\u2019':"'",'\u2014':'-','\u2013':'-','\u2026':'.'}.get(char,char)
            glyph=GLYPHS.get(char,GLYPHS['?'])
            for y in range(7):
                bits=int(glyph[y*2:y*2+2],16)
                for x in range(5):
                    if bits & (1<<(4-x)):
                        pg.draw.rect(result,color,(i*self.advance+x*self.scale,y*self.scale,self.scale,self.scale))
        return result


def pixel_frame(surface,box,fill=(255,254,235),accent=(58,91,121),selected=False):
    """Stepped corners and an inner keyline, like a handheld RPG menu."""
    r=pg.Rect(box)
    pg.draw.rect(surface,(35,57,80),r)
    pg.draw.rect(surface,accent,r.inflate(-4,-4))
    pg.draw.rect(surface,fill,r.inflate(-10,-10))
    pg.draw.rect(surface,(175,205,211),r.inflate(-14,-14),2)
    if selected:
        pg.draw.rect(surface,(222,160,73),r.inflate(-7,-7),3)


def app_icon():
    s=pg.Surface((64,64),pg.SRCALPHA)
    pg.draw.rect(s,(35,72,103),(0,0,64,64),border_radius=8)
    pg.draw.rect(s,(250,240,198),(4,4,56,56),border_radius=5)
    pg.draw.circle(s,(77,165,185),(32,30),23)
    pg.draw.circle(s,(167,222,199),(32,30),20,2)
    pg.draw.ellipse(s,(167,222,199),(22,9,20,42),2)
    pg.draw.line(s,(167,222,199),(11,29),(53,29),2)
    pg.draw.polygon(s,(255,245,200),[(8,30),(27,25),(40,12),(46,12),(38,26),(54,28),(55,33),(37,34),(43,45),(38,45),(26,35),(8,33)])
    return s


SPRITE_FRONT = [
    '................','......oooo......','....oohhhhoo....','...ohhhhhhhho...',
    '...ohhHHHHhho...','..ooCCCCCCCCoo..','..oCCCCCCCCCCo..','...ooSSSSoo.....',
    '....oSSSSSo.....','....oSxSxSo.....','.....oSSSo......','....ooSSSoo.....',
    '...oBBBBBBBBo...','..oSBBbBBBbBSo..','..oSBBbBBBbBSo..','...oBBbBBBbBo...',
    '....oBBBBBBo....','....oBBBBBBo....','....ooPPPPoo....','.....oPPPPo.....',
    '.....oPooPo.....','.....oPooPo.....','....ookookoo....','....ooo..ooo....',
]
SPRITE_BACK = [
    '................','......oooo......','....oohhhhoo....','...ohhhhhhhho...',
    '...ohhHHHHhho...','..ooCCCCCCCCoo..','..oCCCCCCCCCCo..','...ohhhhhho.....',
    '....ohhhhho.....','....ohhhhho.....','.....ohhho......','....ooBBBoo.....',
    '...oBBBBBBBBo...','..oSBBYYYYBBSo..','..oSBYyyyyYBSo..','...oBYyyyyYBo...',
    '....oYyyyyYo....','....oYYYYYYo....','....ooPPPPoo....','.....oPPPPo.....',
    '.....oPooPo.....','.....oPooPo.....','....ookookoo....','....ooo..ooo....',
]
SPRITE_SIDE = [
    '................','......oooo......','.....ohhhhoo....','....ohhhhhho....',
    '....ohHHHHho....','....oCCCCCCooo..','....oCCCCCCCCo..','.....ohSSSSo....',
    '.....ohSSxSo....','.....ohSSSSoo...','......oSSSSo....','.....ooSSoo.....',
    '....oYBBBBBo....','....oYyBBBBBo...','....oYyBSSBBo...','....oYyBSSBBo...',
    '.....oYBBBBBo...','.....oBBBBBo....','.....ooPPPoo....','......oPPPo.....',
    '......oPoPo.....','.....oPPoPo.....','.....okkooko....','.....ooo.ooo....',
]
OUTFITS=[
    ((224,100,91),(48,112,171),(232,181,139),(73,55,64)),
    ((102,160,219),(48,83,124),(183,125,90),(62,47,54)),
    ((236,184,83),(107,89,145),(231,181,139),(110,71,47)),
    ((158,116,195),(62,100,124),(155,101,77),(39,46,59)),
    ((89,181,145),(49,92,104),(215,159,114),(67,45,49)),
    ((237,140,175),(100,107,155),(242,198,154),(132,85,58)),
    ((224,229,203),(91,146,152),(130,84,69),(49,43,53)),
    ((239,151,74),(74,107,151),(211,155,114),(48,50,69)),
]


@lru_cache(maxsize=192)
def character(variant=0,direction='down',step=0,player=False):
    s=pg.Surface((20,28),pg.SRCALPHA)
    shirt,pants,skin,hair=OUTFITS[variant%len(OUTFITS)]
    if player:
        shirt,pants,skin,hair=(72,151,193),(54,77,117),(228,172,123),(56,52,66)
    palette={'o':(37,48,64),'h':hair,'H':tuple(min(255,c+29) for c in hair),
             'C':(239,190,88) if player else shirt,'S':skin,'x':(43,50,62),
             'B':shirt,'b':tuple(max(0,c-24) for c in shirt),'Y':(167,109,66),
             'y':(225,173,96),'P':pants,'k':(73,59,65)}
    pattern=SPRITE_BACK if direction=='up' else SPRITE_SIDE if direction in ('left','right') else SPRITE_FRONT
    pg.draw.ellipse(s,(36,73,73,75),(2,23,17,4))
    for y,row in enumerate(pattern):
        for x,ch in enumerate(row):
            if ch=='.':
                continue
            px=15-x if direction=='left' else x
            py=y
            if y>=20 and step:
                py+=(-1 if x<8 else 1)*(1 if step==1 else -1)
            elif 12<=y<=17 and step and (x<4 or x>11):
                py+=1 if step==1 else -1
            s.set_at((px+2,min(27,py+1)),palette[ch])
    return pg.transform.scale(s,(40,56))
