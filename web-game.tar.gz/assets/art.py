"""Original handheld-era tile and prop art, generated on a small pixel grid."""
import math
from functools import lru_cache
import pygame as pg

INK=(33,53,76)
WHITE=(40,57,76)
GOLD=(34,110,151)
PAPER=(255,254,235)
STYLES={
    'hub': {'grass':(116,194,107),'path':(235,211,158),'water':(66,166,204),'roof':(73,142,185),'leaf':(54,151,99)},
    'frin': {'grass':(129,188,174),'path':(235,205,201),'water':(112,147,211),'roof':(161,114,187),'leaf':(141,118,184)},
    'ansarac': {'grass':(160,197,105),'path':(239,211,155),'water':(79,172,204),'roof':(205,118,83),'leaf':(100,155,83)},
    'mahigul': {'grass':(116,184,137),'path':(214,220,193),'water':(73,168,185),'roof':(76,128,151),'leaf':(49,136,111)},
    'musu': {'grass':(118,202,114),'path':(246,222,165),'water':(53,167,201),'roof':(226,128,83),'leaf':(52,157,112)},
}


def rect(s,color,r,radius=0,width=0):
    pg.draw.rect(s,color,r,width,border_radius=radius)


def tint(color,amount):
    return tuple(max(0,min(255,c+amount)) for c in color)


def scale2(s):
    return pg.transform.scale(s,(s.get_width()*2,s.get_height()*2))


@lru_cache(maxsize=512)
def tile(scene,kind,variant=0,edges=0):
    style=STYLES[scene]
    s=pg.Surface((16,16))
    grass,path,water=style['grass'],style['path'],style['water']
    base=water if kind=='water' else path if kind in ('path','plaza','sand') else grass
    s.fill(base)
    if kind=='water':
        for x,y in [(2,4),(9,11)]:
            pg.draw.line(s,tint(water,22),(x,y),(x+4,y),1)
            s.set_at((x+1,y+1),tint(water,10))
        for bit,r in [(1,(0,0,16,2)),(2,(14,0,2,16)),(4,(0,14,16,2)),(8,(0,0,2,16))]:
            if edges&bit:
                rect(s,(180,232,215),r)
    elif kind in ('path','sand'):
        for x,y in [(3,5),(10,12),(13,3)]:
            s.set_at(((x+variant*3)%16,y),tint(path,-15))
        for bit,r in [(1,(0,0,16,1)),(2,(15,0,1,16)),(4,(0,15,16,1)),(8,(0,0,1,16))]:
            if edges&bit:
                rect(s,tint(path,-26),r)
    elif kind=='plaza':
        rect(s,tint(path,-19),(0,15,16,1))
        rect(s,tint(path,-19),(15,0,1,16))
        rect(s,tint(path,13),(0,0,15,1))
        rect(s,tint(path,13),(0,0,1,15))
        if variant%3==0:
            rect(s,tint(path,-6),(3,3,10,10),0,1)
    else:
        for x,y in [(2,4),(10,11)]:
            x=(x+variant*3)%13
            pg.draw.lines(s,tint(grass,-11),False,[(x,y-1),(x+1,y+1),(x+3,y-2)],1)
            s.set_at((x+3,y+1),tint(grass,12))
        if variant==3:
            rect(s,tint(grass,10),(5,8,3,1))
    return scale2(s)


@lru_cache(maxsize=256)
def prop(kind,scene,variant=0):
    st=STYLES[scene]
    outline=(43,76,81)
    leaf=st['leaf']
    roof=st['roof']
    if kind in ('house','gate','library','cafe'):
        w,h=(88,76) if kind=='library' else (76,68)
        s=pg.Surface((w,h),pg.SRCALPHA)
        pg.draw.ellipse(s,(38,77,75,65),(2,h-9,w-4,9))
        rect(s,outline,(8,22,w-16,h-27))
        rect(s,(248,230,185),(10,24,w-20,h-31))
        rect(s,(220,197,152),(10,h-22,w-20,16))
        rect(s,(255,244,209),(10,25,4,h-33))
        # Stepped tiled roof with a ridge and alternating highlights.
        pg.draw.polygon(s,outline,[(3,26),(10,8),(w-11,8),(w-3,26),(w-3,32),(3,32)])
        pg.draw.polygon(s,roof,[(5,25),(12,10),(w-13,10),(w-5,25),(w-5,29),(5,29)])
        rect(s,tint(roof,36),(13,9,w-26,3))
        for yy in range(15,29,5):
            rect(s,tint(roof,-23),(10-(yy-15)//3,yy,w-20+(yy-15)//2,1))
            for xx in range(13+(yy%2)*4,w-9,9):
                rect(s,tint(roof,18),(xx,yy-3,1,3))
        rect(s,outline,(w//2-8,h-25,17,21))
        rect(s,(116,93,76),(w//2-6,h-23,13,19))
        rect(s,(72,85,89),(w//2-4,h-21,9,9))
        s.set_at((w//2+4,h-12),(249,217,138))
        for x in (15,w-27):
            rect(s,outline,(x,36,13,15))
            rect(s,(107,193,216),(x+2,38,9,11))
            rect(s,(212,244,232),(x+3,39,3,8))
            rect(s,(83,147,151),(x-3,37,3,13))
            rect(s,(83,147,151),(x+13,37,3,13))
            rect(s,(162,102,80),(x-2,51,17,4))
            for dx in (0,5,10):
                rect(s,(81,157,84),(x+dx,49,3,3))
                s.set_at((x+dx+1,48),(240,145,146))
        rect(s,(197,185,151),(w//2-11,h-5,23,3))
        if kind=='gate':
            rect(s,outline,(w//2-13,30,27,9))
            rect(s,[(183,156,221),(234,185,100),(99,178,180),(91,191,151)][variant%4],(w//2-11,32,23,5))
        if kind=='library':
            for x in (8,w-12):
                rect(s,(176,191,171),(x,33,5,35))
                rect(s,(245,236,197),(x,33,2,35))
        if kind=='cafe':
            for i in range(7):
                rect(s,(239,144,132) if i%2==0 else (255,243,205),(w//2-22+i*7,27,7,9))
                rect(s,outline,(w//2-22+i*7,36,7,1))
    elif kind in ('tree','palm'):
        s=pg.Surface((36,48),pg.SRCALPHA)
        pg.draw.ellipse(s,(35,76,74,65),(4,39,29,7))
        rect(s,(76,86,66),(15,27,7,16))
        rect(s,(173,139,83),(16,27,4,15))
        rect(s,(216,168,106),(17,29,2,11))
        if kind=='palm':
            for end in [(3,18),(1,29),(12,5),(26,8),(34,18),(32,29)]:
                pg.draw.line(s,outline,(18,22),end,6)
                pg.draw.line(s,leaf,(18,20),end,4)
                pg.draw.line(s,tint(leaf,34),(18,19),(end[0],end[1]-1),1)
            for x in (15,20):
                rect(s,(157,111,70),(x,23,4,4))
        else:
            for x,y,r in [(12,17,10),(23,17,10),(17,9,9),(8,27,8),(26,27,8),(17,29,10)]:
                pg.draw.circle(s,outline,(x,y),r+1)
            for x,y,r in [(12,16,10),(23,16,10),(17,8,9),(8,26,8),(26,26,8),(17,28,10)]:
                pg.draw.circle(s,leaf,(x,y),r)
            pg.draw.circle(s,tint(leaf,25),(13,9),7)
            pg.draw.circle(s,tint(leaf,15),(8,20),6)
            pg.draw.circle(s,tint(leaf,-16),(25,28),6)
            for x,y in [(13,4),(7,14),(22,11),(12,23),(24,22)]:
                rect(s,tint(leaf,41),(x,y,3,2))
            if variant%3==1:
                for x,y in [(7,22),(21,7),(26,24)]:
                    rect(s,(240,174,108) if scene!='frin' else (245,220,151),(x,y,3,3))
    elif kind=='stall':
        s=pg.Surface((50,39),pg.SRCALPHA)
        rect(s,outline,(3,9,3,29)); rect(s,outline,(43,9,3,29))
        rect(s,(188,143,92),(5,25,39,10)); rect(s,(235,191,121),(5,25,39,3))
        for x in range(4,46,6):
            rect(s,(230,130,133) if (x//6+variant)%2 else (255,236,180),(x,7,6,11))
            rect(s,outline,(x,18,6,1))
        rect(s,(245,228,180),(6,5,38,3))
        for i in range(6):
            pg.draw.circle(s,[(235,156,91),(150,187,92),(234,105,106)][(i+variant)%3],(10+i*6,23),3)
    elif kind=='flowers':
        s=pg.Surface((32,18),pg.SRCALPHA)
        for i in range(7):
            x,y=3+i*4,5+(i*7+variant)%9
            rect(s,(55,144,93),(x,y,1,5))
            color=[(255,220,126),(243,137,171),(232,230,238),(174,139,218)][variant%4]
            pg.draw.line(s,color,(x-2,y),(x+2,y),1)
            pg.draw.line(s,color,(x,y-2),(x,y+2),1)
            s.set_at((x,y),(255,247,176))
    elif kind=='bench':
        s=pg.Surface((36,22),pg.SRCALPHA)
        for x in (4,28):
            rect(s,outline,(x,6,3,15))
        for yy in (3,7,13):
            rect(s,outline,(2,yy,32,4))
            rect(s,(205,156,101),(3,yy,30,2))
    elif kind=='lamp':
        s=pg.Surface((16,40),pg.SRCALPHA)
        rect(s,outline,(7,9,3,28)); rect(s,(149,179,165),(8,12,1,23))
        rect(s,outline,(3,3,11,11)); rect(s,(253,227,152),(5,5,7,7))
        rect(s,outline,(1,2,15,3)); rect(s,outline,(5,37,7,3))
    elif kind=='fountain':
        s=pg.Surface((72,54),pg.SRCALPHA)
        pg.draw.ellipse(s,(57,102,122),(2,20,68,32))
        pg.draw.ellipse(s,(199,215,200),(2,17,68,31))
        pg.draw.ellipse(s,(88,177,202),(7,20,58,23))
        pg.draw.ellipse(s,(177,224,226),(11,23,50,15),1)
        rect(s,(173,199,185),(32,11,8,26))
        pg.draw.ellipse(s,(230,237,205),(22,9,29,10))
        pg.draw.ellipse(s,(106,194,210),(25,10,23,5))
        rect(s,(218,240,223),(35,2,3,10))
    elif kind in ('board','sign','kiosk'):
        s=pg.Surface((36,36),pg.SRCALPHA)
        rect(s,(99,97,78),(7,17,4,18)); rect(s,(99,97,78),(25,17,4,18))
        rect(s,outline,(2,3,32,24)); rect(s,(173,126,82),(4,5,28,20))
        rect(s,(255,240,190),(7,8,22,14))
        for yy in (11,15,19):
            rect(s,(104,140,136),(10,yy,16-(yy%3)*3,1))
        if kind=='kiosk':
            pg.draw.polygon(s,(229,130,113),[(0,5),(18,0),(36,5)])
    elif kind=='loom':
        s=pg.Surface((52,47),pg.SRCALPHA)
        pg.draw.ellipse(s,(79,96,134),(1,35,50,10))
        for x in (8,40):
            rect(s,(77,68,117),(x,2,4,41));rect(s,(240,195,220),(x,2,2,38))
        for yy in range(7,37,4):
            pg.draw.line(s,[(234,191,223),(147,188,222),(252,219,141)][yy%3],(10,yy),(41,yy),2)
        for xx in range(14,40,6):
            pg.draw.line(s,(183,150,199),(xx,5),(xx,36),1)
        rect(s,(248,224,163),(5,1,42,4))
    elif kind=='bookshelf':
        s=pg.Surface((70,43),pg.SRCALPHA)
        rect(s,outline,(1,1,68,41));rect(s,(128,101,79),(3,3,64,37))
        for yy in (6,23):
            for i in range(11):
                c=[(98,172,161),(217,138,114),(224,196,119),(149,145,186)][(i+variant)%4]
                rect(s,c,(6+i*5,yy,4,12));rect(s,tint(c,25),(7+i*5,yy+2,1,2))
            rect(s,(224,190,131),(4,yy+13,62,3))
    elif kind=='table':
        s=pg.Surface((58,39),pg.SRCALPHA)
        for x in (6,47):
            rect(s,outline,(x,23,5,14))
        rect(s,outline,(2,3,54,26));rect(s,(190,144,93),(4,5,50,21))
        rect(s,(240,193,130),(4,5,50,3));rect(s,(255,240,198),(21,10,21,12))
        rect(s,(159,151,128),(31,11,1,10))
    elif kind=='boat':
        s=pg.Surface((58,37),pg.SRCALPHA)
        pg.draw.polygon(s,outline,[(1,20),(56,20),(46,34),(14,34)])
        pg.draw.polygon(s,(209,135,91),[(5,22),(52,22),(44,31),(15,31)])
        rect(s,(242,201,139),(14,23,29,2));rect(s,outline,(28,1,2,24))
        pg.draw.polygon(s,(255,241,192),[(30,1),(30,19),(49,19)])
        pg.draw.polygon(s,(122,185,195),[(27,5),(27,19),(13,19)])
    elif kind=='crops':
        s=pg.Surface((84,34),pg.SRCALPHA)
        rect(s,(135,112,78),(0,0,84,34))
        for yy in (3,14,25):
            rect(s,(183,146,94),(0,yy+5,84,5))
            for xx in range(4,83,11):
                rect(s,(72,134,80),(xx,yy+1,2,6))
                pg.draw.line(s,(101,177,86),(xx-2,yy),(xx,yy+3),2)
                pg.draw.line(s,(158,193,99),(xx,yy+3),(xx+3,yy-1),2)
    elif kind=='windmill':
        s=pg.Surface((66,88),pg.SRCALPHA)
        pg.draw.polygon(s,outline,[(17,82),(22,32),(44,32),(49,82)])
        pg.draw.polygon(s,(244,218,171),[(20,80),(25,33),(41,33),(46,80)])
        pg.draw.polygon(s,roof,[(18,34),(33,16),(48,34)])
        rect(s,(108,104,90),(29,65,10,16))
        for yy in (42,52):
            rect(s,(91,155,171),(30,yy,7,6))
        for a in (45,135,225,315):
            dx,dy=math.cos(math.radians(a)),math.sin(math.radians(a))
            pg.draw.line(s,outline,(33,35),(33+int(dx*33),35+int(dy*33)),5)
            pg.draw.line(s,(238,224,184),(33+int(dx*8),35+int(dy*8)),(33+int(dx*32),35+int(dy*32)),3)
        pg.draw.circle(s,(123,108,84),(33,35),5)
    elif kind=='banner':
        s=pg.Surface((128,28),pg.SRCALPHA)
        for i in range(12):
            x=5+i*10
            y=4+int(math.sin(i/11*math.pi)*9)
            if i:
                pg.draw.line(s,(101,112,107),previous,(x,y),1)
            c=[(240,147,144),(250,211,125),(121,194,190),(175,153,210)][i%4]
            pg.draw.polygon(s,c,[(x,y),(x+8,y),(x+4,y+10)])
            previous=(x,y)
    elif kind=='airplane':
        s=pg.Surface((100,60),pg.SRCALPHA)
        pg.draw.ellipse(s,(58,101,124,60),(9,42,81,13))
        shape=[(8,27),(37,22),(58,2),(67,2),(57,22),(86,24),(94,16),(98,16),(95,28),(98,40),(94,40),(86,33),(57,34),(67,54),(58,54),(37,35),(8,31)]
        pg.draw.polygon(s,outline,shape)
        inner=[(10,28),(39,24),(59,4),(64,4),(53,24),(87,26),(95,20),(92,28),(95,36),(87,31),(53,32),(64,51),(59,51),(39,33),(10,30)]
        pg.draw.polygon(s,(248,247,219),inner)
        rect(s,(70,143,178),(15,26,7,7));rect(s,(144,203,211),(15,26,4,3))
        for xx in range(28,78,8):
            rect(s,(90,165,190),(xx,27,3,2))
        pg.draw.line(s,(225,166,99),(52,18),(59,7),3)
    elif kind in ('book_statue','star_shrine'):
        s=pg.Surface((54,62),pg.SRCALPHA)
        pg.draw.ellipse(s,(62,109,113,70),(3,51,48,10))
        rect(s,outline,(7,44,40,13));rect(s,(189,209,192),(9,44,36,10))
        rect(s,(222,228,201),(12,39,30,8));rect(s,(155,188,182),(23,19,8,23))
        if kind=='book_statue':
            pg.draw.polygon(s,outline,[(5,5),(27,9),(49,5),(49,29),(27,33),(5,29)])
            pg.draw.polygon(s,(255,235,180),[(7,7),(26,11),(26,30),(7,27)])
            pg.draw.polygon(s,(232,211,161),[(28,11),(47,7),(47,27),(28,30)])
            for yy in (14,19,24):
                pg.draw.line(s,(167,161,130),(11,yy),(22,yy+2),1)
        else:
            points=[]
            for i in range(10):
                a=-math.pi/2+i*math.pi/5
                rr=21 if i%2==0 else 10
                points.append((27+int(math.cos(a)*rr),21+int(math.sin(a)*rr)))
            pg.draw.polygon(s,(102,102,146),points)
            pg.draw.polygon(s,(251,217,143),[(27+int((x-27)*.85),21+int((y-21)*.85)) for x,y in points])
    elif kind=='crate':
        s=pg.Surface((24,23),pg.SRCALPHA)
        rect(s,outline,(1,2,22,20));rect(s,(192,147,90),(3,4,18,16))
        rect(s,(228,183,114),(3,4,18,3));pg.draw.line(s,(131,104,73),(4,8),(19,18),2)
        pg.draw.line(s,(131,104,73),(19,8),(4,18),2)
    else:
        s=pg.Surface((22,25),pg.SRCALPHA)
        rect(s,outline,(2,3,18,20));rect(s,(205,155,96),(4,5,14,16))
    return scale2(s)


def emblem(surface,center,motif,color,size=24):
    x,y=center
    pg.draw.circle(surface,color,center,size,2)
    if motif in ('frin','sea'):
        for dy in (-5,5):
            points=[(x-size+7+i*3,y+dy+int(math.sin(i*.7)*3)) for i in range(max(2,(size*2-14)//3))]
            pg.draw.lines(surface,color,False,points,2)
    elif motif in ('ansarac','bird'):
        pg.draw.lines(surface,color,False,[(x-13,y+5),(x,y-7),(x+13,y+5)],3)
        pg.draw.line(surface,color,(x,y-7),(x,y+12),2)
    elif motif in ('mahigul','tree'):
        pg.draw.lines(surface,color,False,[(x-13,y+10),(x-13,y-9),(x,y-5),(x+13,y-9),(x+13,y+10),(x,y+14),(x-13,y+10)],2)
        pg.draw.line(surface,color,(x,y-5),(x,y+13),2)
    else:
        pg.draw.circle(surface,color,(x,y),8,2)
        for a in range(0,360,60):
            dx,dy=math.cos(math.radians(a)),math.sin(math.radians(a))
            pg.draw.line(surface,color,(x+int(dx*12),y+int(dy*12)),(x+int(dx*17),y+int(dy*17)),2)
